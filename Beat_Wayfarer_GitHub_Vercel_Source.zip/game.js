// ============================================
// BEAT WAYFARER — Medieval to Space Rhythm Game
// ============================================

(function () {
'use strict';

// ---------- CONSTANTS ----------
const LANES = 4;
const DEFAULT_KEYS = ['KeyD', 'KeyF', 'KeyJ', 'KeyK'];
const KEYBIND_STORAGE_KEY = 'rhythmRiseKeybinds';
let KEYS = loadKeybinds();
let KEY_LABELS = KEYS.map(codeToLabel);

// Turn a KeyboardEvent.code into a short display label
function codeToLabel(code) {
  if (!code) return '?';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  if (code.startsWith('Numpad')) return 'NUM' + code.slice(6);
  const special = {
    Space: 'SPACE',
    ArrowUp: '↑',
    ArrowDown: '↓',
    ArrowLeft: '←',
    ArrowRight: '→',
    ShiftLeft: 'L-SHIFT',
    ShiftRight: 'R-SHIFT',
    ControlLeft: 'L-CTRL',
    ControlRight: 'R-CTRL',
    AltLeft: 'L-ALT',
    AltRight: 'R-ALT',
    Semicolon: ';',
    Quote: "'",
    Comma: ',',
    Period: '.',
    Slash: '/',
    Backslash: '\\',
    BracketLeft: '[',
    BracketRight: ']',
    Backquote: '`',
    Minus: '-',
    Equal: '=',
    Tab: 'TAB',
    CapsLock: 'CAPS',
    Enter: 'ENTER',
    Backspace: 'BKSP',
  };
  if (special[code]) return special[code];
  return code.replace(/^Key|^Digit/, '').toUpperCase();
}

function loadKeybinds() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEYBIND_STORAGE_KEY));
    if (Array.isArray(saved) && saved.length === LANES && saved.every(c => typeof c === 'string')) {
      return saved;
    }
  } catch (_error) {}
  return DEFAULT_KEYS.slice();
}

function saveKeybinds() {
  try {
    localStorage.setItem(KEYBIND_STORAGE_KEY, JSON.stringify(KEYS));
  } catch (_error) {}
}

// Judgement windows (ms)
const PERFECT_WINDOW = 60;
const GOOD_WINDOW = 120;
const MISS_WINDOW = 180;

// Game constants
const NOTE_SPEED = 320; // pixels per second (visual)
const HIT_LINE_Y_RATIO = 0.82; // desktop hit line

// Keep the target circles above the finger-control bar on small touch screens.
// This leaves a dedicated playfield area instead of letting the HTML controls
// cover the canvas targets.
function getHitLineY() {
  const isSmallTouch = window.matchMedia('(max-width: 700px)').matches &&
    (window.matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window);
  if (!isSmallTouch) return H * HIT_LINE_Y_RATIO;
  return Math.max(120, Math.min(H * 0.72, H - 145));
}
const NOTE_SPAWN_AHEAD = 2.5; // seconds ahead to spawn notes
const HP_MAX = 100;
const HP_LOSS = 5;
const HP_GAIN_PERFECT = 2;
const HP_GAIN_GOOD = 1;
const PASS_THRESHOLD = 0.6; // 60% accuracy to pass
const START_DELAY = 3.0; // seconds of lead-in before a song's first beat

// ---------- ERA DEFINITIONS ----------
// Each era carries its own short melodic motif (indices into that era's
// `scale`) so the procedural music has a distinct, recognizable hook per
// level rather than every level walking the scale the same way. The
// melody scheduler below cycles through this motif in step with the
// falling notes, which is also what keeps each note's arrival in sync
// with an audible hit.
const ERAS = [
  { name:'The Slums', sub:'A poor medieval town', bpm:72, scale:[196,220,233,261,294,311,349], bassFreq:98, melodyType:'square', bassType:'triangle', instrument:'piano', drums:false, motif:[0,0,2,0,3,2,0,1],
    palette:{skyTop:'#1a1220',skyBot:'#2d1f1a',ground:'#1a1a22',building:'#3a2a2a',buildingLight:'#4a342e',accent:'#6b4a3a',text:'#c4a884',noteColors:['#c4744a','#d4a44a','#7a9a4a','#9a6a4a'],laneGlow:'rgba(196,116,74,.15)',stars:false,neon:false}, density:.30, pattern:'simple', backgroundType:'slums', buildingStyle:'slums' },
  { name:'Old Market', sub:'Lanterns, stalls, and busy streets', bpm:84, scale:[196,220,247,262,294,330,370], bassFreq:98, melodyType:'square', bassType:'triangle', instrument:'marimba', drums:false, motif:[0,2,1,3,2,4,3,2],
    palette:{skyTop:'#20161a',skyBot:'#3a281c',ground:'#201a18',building:'#4a3026',buildingLight:'#62402e',accent:'#a06a3a',text:'#d6b27c',noteColors:['#d47a4a','#e0b34f','#7ca05a','#b06d4d'],laneGlow:'rgba(212,122,74,.16)',stars:false,neon:false}, density:.36, pattern:'simple', backgroundType:'market' },
  { name:'Riverside Alley', sub:'Lanterns beside the old river', bpm:90, scale:[208,233,247,277,311,330,370], bassFreq:104, melodyType:'triangle', bassType:'triangle', instrument:'flute', drums:false, motif:[0,1,2,3,2,1,0,4],
    palette:{skyTop:'#181820',skyBot:'#2f2620',ground:'#1d1a1b',building:'#49332b',buildingLight:'#654537',accent:'#a36b3f',text:'#d2ad7b',noteColors:['#d07a4e','#d8a54c','#8aa45a','#a97855'],laneGlow:'rgba(208,122,78,.17)',stars:false,neon:false}, density:.40, pattern:'simple', backgroundType:'riverside' },
  { name:'Foundry Row', sub:'Smoke, sparks, and steel', bpm:102, scale:[220,247,277,294,330,370,415], bassFreq:110, melodyType:'square', bassType:'sawtooth', instrument:'organ', drums:false, motif:[0,0,3,3,1,1,4,4],
    palette:{skyTop:'#21181a',skyBot:'#3a2520',ground:'#211b1a',building:'#4b3028',buildingLight:'#704335',accent:'#c16a3b',text:'#d8b07c',noteColors:['#df7445','#e0a844','#879c55','#b56a4c'],laneGlow:'rgba(193,106,59,.18)',stars:false,neon:false}, density:.47, pattern:'medium', backgroundType:'foundry' },
  { name:'Merchant Quarter', sub:'Trade brings life and color', bpm:96, scale:[220,247,262,294,330,370,415], bassFreq:110, melodyType:'square', bassType:'triangle', instrument:'pluck', drums:false, motif:[0,2,4,2,1,3,5,3],
    palette:{skyTop:'#2a2018',skyBot:'#3a2a18',ground:'#2a2218',building:'#5a3a22',buildingLight:'#6a4a2a',accent:'#8a6a3a',text:'#d4b484',noteColors:['#d4844a','#d4b44a','#8aaa5a','#aa7a4a'],laneGlow:'rgba(212,132,74,.18)',stars:false,neon:false}, density:.45, pattern:'medium', backgroundType:'merchant' },
  { name:'Old Harbor', sub:'Salt air and lantern-lit water', bpm:106, scale:[233,262,294,330,349,392,440], bassFreq:117, melodyType:'triangle', bassType:'triangle', instrument:'violin', drums:false, motif:[0,3,1,4,2,5,3,6],
    palette:{skyTop:'#12202a',skyBot:'#1e3340',ground:'#142128',building:'#29414b',buildingLight:'#3a5962',accent:'#5fa0aa',text:'#b8d9d9',noteColors:['#55a7c7','#7cc5d0','#d5b45a','#a7d38a'],laneGlow:'rgba(95,160,170,.18)',stars:false,neon:false}, density:.50, pattern:'medium', backgroundType:'harbor' , buildingStyle:'harbor' },
  { name:'Noble District', sub:'Wealth and elegance', bpm:116, scale:[262,294,330,349,392,440,494], bassFreq:131, melodyType:'square', bassType:'sawtooth', instrument:'harp', drums:false, motif:[0,4,2,5,3,6,4,2],
    palette:{skyTop:'#1a2a2a',skyBot:'#2a3a3a',ground:'#222a2a',building:'#3a4a5a',buildingLight:'#4a5a6a',accent:'#6a8aaa',text:'#b4d4e4',noteColors:['#5a9ad4','#7ab4d4','#d4b45a','#b49a6a'],laneGlow:'rgba(90,154,212,.18)',stars:false,neon:false}, density:.55, pattern:'medium', backgroundType:'noble', buildingStyle:'noble' },
  { name:'Castle Gardens', sub:'A quiet garden beneath the castle', bpm:128, scale:[262,294,330,392,440,494,523], bassFreq:131, melodyType:'triangle', bassType:'triangle', instrument:'bell', drums:false, motif:[0,2,3,5,4,6,5,3],
    palette:{skyTop:'#16261d',skyBot:'#29402c',ground:'#1c2a20',building:'#314a34',buildingLight:'#476449',accent:'#79a85b',text:'#c2d89a',noteColors:['#6ebd75','#a8c85b','#d9b65a','#7bb6a8'],laneGlow:'rgba(121,168,91,.18)',stars:false,neon:false}, density:.60, pattern:'fast', backgroundType:'gardens', buildingStyle:'gardens' },
  { name:'Royal Court', sub:'The king demands a dance', bpm:140, scale:[294,330,370,392,440,494,554], bassFreq:147, melodyType:'square', bassType:'sawtooth', instrument:'trumpet', drums:true, motif:[0,4,4,6,4,2,4,0],
    palette:{skyTop:'#2a1a3a',skyBot:'#3a2a4a',ground:'#2a223a',building:'#4a3a5a',buildingLight:'#5a4a6a',accent:'#8a6aaa',text:'#d4b4e4',noteColors:['#b48ad4','#d4a4e4','#e4d4b4','#d4b48a'],laneGlow:'rgba(180,138,212,.2)',stars:false,neon:false}, density:.65, pattern:'fast', backgroundType:'court', buildingStyle:'court' },
  { name:'Orbital Outpost', sub:'The first step beyond the sky', bpm:150, scale:[220,233,277,294,330,370,415], bassFreq:55, melodyType:'sawtooth', bassType:'square', instrument:'synth', drums:true, motif:[0,3,6,3,1,4,6,4],
    palette:{skyTop:'#070a18',skyBot:'#0b1730',ground:'#080c18',building:'#17284a',buildingLight:'#29486a',accent:'#4a9cff',text:'#8bd0ff',noteColors:['#39a9ff','#9b6cff','#52e0c4','#ffb84a'],laneGlow:'rgba(74,156,255,.22)',stars:true,neon:true}, density:.70, pattern:'fast', backgroundType:'orbit', buildingStyle:'orbit' },
  { name:'Space Station', sub:'Funk rules the final frontier', bpm:160, scale:[220,233,277,294,330,370,415], bassFreq:55, melodyType:'sawtooth', bassType:'square', instrument:'electricBass', drums:true, motif:[0,5,3,6,2,5,1,4],
    palette:{skyTop:'#0a0a1a',skyBot:'#0a1a2a',ground:'#0a0a1a',building:'#1a2a4a',buildingLight:'#2a4a6a',accent:'#00ffaa',text:'#4afaea',noteColors:['#00ffaa','#ff44aa','#4afaea','#ffaa44'],laneGlow:'rgba(0,255,170,.25)',stars:true,neon:true}, density:.75, pattern:'funk', backgroundType:'space', buildingStyle:'space' },
  { name:'Moonlit Ballroom', sub:'A grand dance beneath crystal chandeliers', bpm:132, scale:[262,294,330,349,392,440,494], bassFreq:131, melodyType:'triangle', bassType:'triangle', instrument:'celesta', drums:true, motif:[0,2,4,5,4,2,1,3],
    palette:{skyTop:'#160f24',skyBot:'#3b2348',ground:'#24172d',building:'#4d315d',buildingLight:'#765184',accent:'#d9a6e8',text:'#f1d9f5',noteColors:['#d98be8','#e7b6f2','#b7a6e8','#f0d28b'],laneGlow:'rgba(217,166,232,.22)',stars:false,neon:false}, density:.62, pattern:'fast', backgroundType:'ballroom', buildingStyle:'ballroom' },
  { name:'Crystal Caverns', sub:'Echoes beneath the ancient earth', bpm:146, scale:[196,233,262,294,349,392,466], bassFreq:98, melodyType:'sine', bassType:'triangle', instrument:'cello', drums:false, motif:[0,3,5,3,1,4,6,4],
    palette:{skyTop:'#08151b',skyBot:'#12353d',ground:'#071a20',building:'#17434b',buildingLight:'#2b6871',accent:'#58d4d4',text:'#bceff0',noteColors:['#57d9e1','#88b9ff','#9ee58c','#d7c66d'],laneGlow:'rgba(88,212,212,.22)',stars:false,neon:false}, density:.72, pattern:'fast', backgroundType:'crystal', buildingStyle:'crystal' },
  { name:'Dragon\'s Throne', sub:'The final march to the throne', bpm:150, afterBpm:190, cutsceneDuration:5.0, finale:true,
    scale:[220,247,277,330,370,440,494], bassFreq:110, melodyType:'square', bassType:'sawtooth', instrument:'brass', drums:true, motif:[0,2,4,2,0,3,5,3], motifPost:[0,4,6,4,2,5,6,4],
    palette:{skyTop:'#1b0b0b',skyBot:'#351414',ground:'#180d0d',building:'#3b2020',buildingLight:'#6a3430',accent:'#d78a32',text:'#f1c56b',noteColors:['#e05a3f','#f0b33c','#d6c15a','#b84d38'],laneGlow:'rgba(224,90,63,.22)',stars:false,neon:false}, density:.68, pattern:'fast', backgroundType:'finale', buildingStyle:'castle' },
];

// ---------- CUSTOM LEVEL (player-made final level) ----------
// A user-made level slots in after all built-in eras as the true
// final level. ACTIVE_ERAS is what the rest of the game reads from;
// it's ERAS plus the custom level whenever one has been saved.
let customLevel = null;
let ACTIVE_ERAS = ERAS.slice();

function refreshActiveEras() {
  ACTIVE_ERAS = customLevel ? ERAS.concat([customLevel]) : ERAS.slice();
}

// ---------- CUSTOM LEVEL STORAGE (IndexedDB for audio + localStorage for the rest) ----------
const CUSTOM_LEVEL_META_KEY = 'rhythmRiseCustomLevelMeta';
const CUSTOM_DB_NAME = 'rhythmRiseCustomDB';
const CUSTOM_DB_STORE = 'audio';
const CUSTOM_DB_KEY = 'customLevelAudio';

function openCustomDB() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) { reject(new Error('no indexedDB')); return; }
    const req = indexedDB.open(CUSTOM_DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(CUSTOM_DB_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveCustomAudioBlob(blob) {
  const db = await openCustomDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CUSTOM_DB_STORE, 'readwrite');
    tx.objectStore(CUSTOM_DB_STORE).put(blob, CUSTOM_DB_KEY);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function loadCustomAudioBlob() {
  const db = await openCustomDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(CUSTOM_DB_STORE, 'readonly');
    const req = tx.objectStore(CUSTOM_DB_STORE).get(CUSTOM_DB_KEY);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

async function deleteCustomAudioBlob() {
  try {
    const db = await openCustomDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(CUSTOM_DB_STORE, 'readwrite');
      tx.objectStore(CUSTOM_DB_STORE).delete(CUSTOM_DB_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (_error) {}
}

function saveCustomLevelMeta(meta) {
  try {
    localStorage.setItem(CUSTOM_LEVEL_META_KEY, JSON.stringify(meta));
  } catch (_error) {}
}

function loadCustomLevelMeta() {
  try {
    const raw = localStorage.getItem(CUSTOM_LEVEL_META_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (_error) {
    return null;
  }
}

function deleteCustomLevel() {
  try { localStorage.removeItem(CUSTOM_LEVEL_META_KEY); } catch (_error) {}
  deleteCustomAudioBlob();
  if (customLevel && customLevel.audioUrl) {
    try { URL.revokeObjectURL(customLevel.audioUrl); } catch (_error) {}
  }
  customLevel = null;
  refreshActiveEras();
}

// Build the era-shaped object the game engine expects from saved meta + blob
function buildCustomEra(meta, audioBlob) {
  const sourceUrl = meta.audioUrl || (audioBlob ? URL.createObjectURL(audioBlob) : '');
  return {
    name: meta.name || 'Your Level',
    sub: meta.sub || 'A custom creation',
    custom: true,
    audioUrl: sourceUrl,
    palette: meta.palette,
    buildings: meta.buildings || { motion: 'static', amount: 0, offsetX: 0, offsetY: 0, bump: 0, width: 44, height: 80, imageScale: 100, imageMode: 'procedural', imageData: null },
    chart: meta.chart, // { notes: [...], duration }
    density: 0.5,
    pattern: 'custom',
  };
}

async function loadCustomLevelFromStorage() {
  const meta = loadCustomLevelMeta();
  if (!meta) return;
  try {
    if (meta.audioUrl) {
      customLevel = buildCustomEra(meta, null);
    } else {
      const blob = await loadCustomAudioBlob();
      if (!blob) return;
      customLevel = buildCustomEra(meta, blob);
    }
    refreshActiveEras();
  } catch (_error) {
    // IndexedDB unavailable or blob missing — silently skip
  }
}

// ---------- AUDIO ENGINE ----------
const AudioEngine = {
  ctx: null,
  masterGain: null,
  musicGain: null,
  sfxGain: null,
  initialized: false,

  init() {
    if (this.initialized) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0.7;
    this.masterGain.connect(this.ctx.destination);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.5;
    this.musicGain.connect(this.masterGain);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = 0.3;
    this.sfxGain.connect(this.masterGain);

    this.initialized = true;
    applyAudioSettings();
  },

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  },

  // Play a single note
  playNote(freq, duration, type, gainValue, when) {
    if (!this.ctx) return;
    const t = when || this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type || 'square';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(gainValue || 0.3, t + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
    osc.connect(gain).connect(this.musicGain);
    osc.start(t);
    osc.stop(t + duration + 0.05);
  },

  // Play a distinct instrument-like voice for each level.
  // These are lightweight WebAudio synth patches so every level has its own
  // timbre without requiring external audio files.
  playInstrument(freq, duration, instrument, gainValue, when) {
    if (!this.ctx) return;
    const t = when || this.ctx.currentTime;
    const presets = {
      piano:       {type:'triangle', attack:0.004, release:0.55, filter:2600, detune:0},
      marimba:     {type:'sine', attack:0.002, release:0.30, filter:3400, detune:7},
      flute:       {type:'sine', attack:0.035, release:0.45, filter:2200, detune:0},
      organ:       {type:'square', attack:0.018, release:0.70, filter:1800, detune:0},
      pluck:       {type:'sawtooth', attack:0.002, release:0.22, filter:3000, detune:4},
      violin:      {type:'sawtooth', attack:0.045, release:0.65, filter:2500, detune:0},
      harp:        {type:'triangle', attack:0.002, release:0.75, filter:4200, detune:-5},
      bell:        {type:'sine', attack:0.001, release:0.90, filter:5000, detune:12},
      trumpet:     {type:'square', attack:0.025, release:0.32, filter:1900, detune:-3},
      synth:       {type:'sawtooth', attack:0.008, release:0.42, filter:3200, detune:0},
      electricBass:{type:'triangle', attack:0.006, release:0.38, filter:1400, detune:0},
      brass:       {type:'sawtooth', attack:0.025, release:0.50, filter:2100, detune:2},
      celesta:     {type:'sine', attack:0.002, release:1.05, filter:5200, detune:4},
      cello:       {type:'sawtooth', attack:0.055, release:0.85, filter:1500, detune:-4}
    };
    const p = presets[instrument] || presets.piano;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    osc.type = p.type;
    osc.frequency.value = freq;
    osc.detune.value = p.detune;
    filter.type = 'lowpass';
    filter.frequency.value = p.filter;
    filter.Q.value = instrument === 'bell' ? 1.5 : 0.7;
    const peak = gainValue || 0.22;
    const end = t + Math.max(0.08, duration);
    const releaseEnd = end + p.release * 0.35;
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(peak, t + p.attack);
    gain.gain.exponentialRampToValueAtTime(0.001, releaseEnd);
    osc.connect(filter).connect(gain).connect(this.musicGain);
    osc.start(t);
    osc.stop(releaseEnd + 0.03);

    // Add a quiet octave partial to make the patch less like a single
    // oscillator and more like a recognizable instrument.
    if (instrument === 'piano' || instrument === 'harp' || instrument === 'bell' || instrument === 'brass' || instrument === 'celesta') {
      const partial = this.ctx.createOscillator();
      const pg = this.ctx.createGain();
      partial.type = 'sine';
      partial.frequency.value = freq * 2;
      pg.gain.setValueAtTime(0.0001, t);
      pg.gain.linearRampToValueAtTime(peak * 0.18, t + p.attack);
      pg.gain.exponentialRampToValueAtTime(0.001, releaseEnd * 0.98);
      partial.connect(pg).connect(this.musicGain);
      partial.start(t);
      partial.stop(releaseEnd + 0.03);
    }
  },

  // A short musical click exactly at a chart note's beat time.
  playBeatClick(instrument, when, accent) {
    if (!this.ctx) return;
    const t = when || this.ctx.currentTime;
    const freq = accent ? 1760 : 1320;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = instrument === 'bell' || instrument === 'harp' ? 'sine' : 'square';
    osc.frequency.setValueAtTime(freq, t);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.linearRampToValueAtTime(accent ? 0.10 : 0.065, t + 0.002);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.045);
    osc.connect(gain).connect(this.musicGain);
    osc.start(t);
    osc.stop(t + 0.055);
  },

  // Play bass note
  playBass(freq, duration, type, when) {
    if (!this.ctx) return;
    const t = when || this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type || 'triangle';
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.25, t + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
    osc.connect(gain).connect(this.musicGain);
    osc.start(t);
    osc.stop(t + duration + 0.05);
  },

  // Play drum (noise burst for hihat, low thump for kick)
  playDrum(type, when) {
    if (!this.ctx) return;
    const t = when || this.ctx.currentTime;
    if (type === 'kick') {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(30, t + 0.1);
      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
      osc.connect(gain).connect(this.musicGain);
      osc.start(t);
      osc.stop(t + 0.2);
    } else if (type === 'hihat') {
      const noise = this.ctx.createBufferSource();
      const buffer = this.ctx.createBuffer(1, 2048, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 2048; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 7000;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.15, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      noise.connect(filter).connect(gain).connect(this.musicGain);
      noise.start(t);
      noise.stop(t + 0.06);
    } else if (type === 'snare') {
      const noise = this.ctx.createBufferSource();
      const buffer = this.ctx.createBuffer(1, 4096, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 4096; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 2000;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      noise.connect(filter).connect(gain).connect(this.musicGain);
      noise.start(t);
      noise.stop(t + 0.12);
    }
  },

  // SFX for hitting notes
  playHitSFX(lane, judgement) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const freqs = [440, 523, 659, 784];
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = judgement === 'perfect' ? 'square' : 'triangle';
    osc.frequency.value = freqs[lane] || 440;
    if (judgement === 'perfect') osc.frequency.value *= 1.5;
    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc.connect(gain).connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.1);
  },

  // SFX for miss
  playMissSFX() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(200, t);
    osc.frequency.exponentialRampToValueAtTime(80, t + 0.15);
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
    osc.connect(gain).connect(this.sfxGain);
    osc.start(t);
    osc.stop(t + 0.2);
  },
};

// ---------- AUDIO VOLUME SETTINGS ----------
const AUDIO_SETTINGS_KEY = 'beatWayfarerAudioSettings';
const AudioSettings = { music: 100, sfx: 100 };
function loadAudioSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem(AUDIO_SETTINGS_KEY) || '{}');
    if (Number.isFinite(saved.music)) AudioSettings.music = Math.max(0, Math.min(150, saved.music));
    if (Number.isFinite(saved.sfx)) AudioSettings.sfx = Math.max(0, Math.min(150, saved.sfx));
  } catch (_) {}
}
function applyAudioSettings() {
  if (!AudioEngine.ctx) return;
  AudioEngine.musicGain.gain.setTargetAtTime(0.5 * (AudioSettings.music / 100), AudioEngine.ctx.currentTime, 0.01);
  AudioEngine.sfxGain.gain.setTargetAtTime(0.3 * (AudioSettings.sfx / 100), AudioEngine.ctx.currentTime, 0.01);
}
function saveAudioSettings() {
  localStorage.setItem(AUDIO_SETTINGS_KEY, JSON.stringify(AudioSettings));
  applyAudioSettings();
}
loadAudioSettings();

// ---------- CHART GENERATOR ----------
// Generate the special finale chart: a slower first march, a mid-level dragon
// cutscene, then a faster final charge.
function generateFinaleChart(era) {
  const preBpm = era.bpm || 150;
  const postBpm = era.afterBpm || 190;
  const preBeats = 36;
  const postBeats = 40;
  const cutsceneAt = era.cutsceneAt || (START_DELAY + preBeats * 60 / preBpm);
  const cutsceneDuration = era.cutsceneDuration || 5;
  era.cutsceneAt = cutsceneAt;
  era.cutsceneDuration = cutsceneDuration;
  const notes = [];
  const musicBeatTimes = [];
  const pattern = [
    [0,0],[1,1],[2,2],[3,3],[0,4],[2,5],[1,6],[3,7],
    [2,8],[0,9],[3,10],[1,11],[0,12],[3,13],[2,14],[1,15]
  ];
  const span = 16;
  for (let beat = 0; beat < preBeats; beat++) {
    const t = START_DELAY + beat * 60 / preBpm;
    musicBeatTimes.push({time:t,bpm:preBpm,section:'pre',step:beat,sub:false});
  }
  const postStart = cutsceneAt + cutsceneDuration;
  // The post-cutscene note pattern below lands notes on half-beats too
  // (see `extra` and the harmony notes further down), so the music grid
  // here is scheduled at the same half-beat resolution — every falling
  // note gets a matching audible hit instead of some landing between
  // scheduled music beats.
  for (let half = 0; half < postBeats * 2; half++) {
    const t = postStart + half * 0.5 * 60 / postBpm;
    musicBeatTimes.push({time:t,bpm:postBpm,section:'post',step:half,sub: half % 2 === 1});
  }
  for (let beat = 0; beat < preBeats; beat++) {
    const [lane, off] = pattern[beat % span];
    notes.push({lane,time:START_DELAY + beat*60/preBpm,hit:false,missed:false,y:-50,spawned:false});
  }
  for (let beat = 0; beat < postBeats; beat++) {
    const [lane, off] = pattern[(beat + 4) % span];
    const extra = (beat % 4 === 1 || beat % 4 === 3) ? 0.5 : 0;
    const t = postStart + (beat + extra) * 60 / postBpm;
    notes.push({lane,time:t,hit:false,missed:false,y:-50,spawned:false});
    if (beat % 8 === 3 || beat % 8 === 7) {
      notes.push({lane:(lane+2)%LANES,time:t+30/postBpm,hit:false,missed:false,y:-50,spawned:false});
    }
  }
  notes.sort((a,b)=>a.time-b.time);
  return {notes,duration:postStart + postBeats*60/postBpm + 2,musicBeatTimes,cutsceneAt,cutsceneDuration};
}

// Generate a note chart from era beat pattern
function generateChart(era, levelIndex) {
  const beatsPerSec = era.bpm / 60;
  const totalBeats = 32 + levelIndex * 8; // 32-64 beats
  const notes = [];
  
  const beatInterval = 1 / beatsPerSec;
  let beat = 0;
  
  // Pattern templates per era
  const patterns = {
    simple: [
      [0, 0], [2, 2], [1, 4], [3, 6],
      [0, 8], [2, 10], [1, 12], [3, 14],
      [0, 16], [2, 18], [3, 20], [1, 22],
      [2, 24], [0, 26], [3, 28], [1, 30],
    ],
    medium: [
      [0, 0], [1, 1], [2, 2], [3, 3],
      [0, 4], [2, 5], [1, 6], [3, 7],
      [2, 8], [0, 9], [3, 10], [1, 11],
      [0, 12], [3, 13], [2, 14], [1, 15],
      [1, 16], [3, 17], [0, 18], [2, 19],
      [3, 20], [1, 21], [2, 22], [0, 23],
      [0, 24], [2, 25], [1, 26], [3, 27],
      [3, 28], [1, 29], [2, 30], [0, 31],
    ],
    fast: [
      [0, 0], [1, 0.5], [2, 1], [3, 1.5],
      [0, 2], [2, 2.5], [1, 3], [3, 3.5],
      [2, 4], [0, 4.5], [3, 5], [1, 5.5],
      [0, 6], [3, 6.5], [1, 7], [2, 7.5],
      [1, 8], [3, 8.5], [0, 9], [2, 9.5],
      [3, 10], [0, 10.5], [1, 11], [2, 11.5],
      [0, 12], [1, 12.5], [2, 13], [3, 13.5],
      [2, 14], [3, 14.5], [0, 15], [1, 15.5],
    ],
    funk: [
      [0, 0], [2, 0.5], [1, 1], [3, 1.5],
      [0, 2], [1, 2.5], [2, 3], [3, 3.5],
      [3, 4], [0, 4.5], [2, 5], [1, 5.5],
      [0, 6], [3, 6.5], [2, 7], [1, 7.5],
      [1, 8], [0, 8.5], [3, 9], [2, 9.5],
      [2, 10], [1, 10.5], [0, 11], [3, 11.5],
      [0, 12], [2, 12.5], [3, 13], [1, 13.5],
      [3, 14], [0, 14.5], [1, 15], [2, 15.5],
    ],
  };

  const pattern = patterns[era.pattern] || patterns.simple;
  
  // Calculate the beat span of the pattern (max beat offset + 1)
  const patternSpanBeats = Math.ceil(Math.max(...pattern.map(p => p[1])) + 1);
  const totalDuration = START_DELAY + totalBeats * beatInterval;
  const loopsNeeded = Math.ceil(totalBeats / patternSpanBeats);
  
  for (let loop = 0; loop < loopsNeeded; loop++) {
    for (const [lane, beatOffset] of pattern) {
      const noteBeat = loop * patternSpanBeats + beatOffset;
      if (noteBeat < totalBeats) {
        const time = START_DELAY + noteBeat * beatInterval;
        notes.push({
          lane: lane,
          time: time,
          hit: false,
          missed: false,
          y: -50, // visual position
          spawned: false,
        });
      }
    }
  }
  
  // Sort by time
  notes.sort((a, b) => a.time - b.time);
  return { notes, duration: totalDuration };
}

// ---------- MUSIC SEQUENCER ----------
// Plays background music synced to AudioContext clock
const MusicSequencer = {
  scheduledNotes: [],
  scheduledTime: 0,
  beatIndex: 0,
  active: false,
  songStartTime: 0,
  era: null,
  chart: null,
  musicBeatIndex: 0,
  chartNoteIndex: 0,

  start(era, chart) {
    this.era = era;
    this.chart = chart;
    this.beatIndex = 0;
    this.musicBeatIndex = 0;
    this.chartNoteIndex = 0;
    this.scheduledTime = AudioEngine.ctx.currentTime + 0.1;
    this.songStartTime = this.scheduledTime;
    this.active = true;
  },

  stop() {
    this.active = false;
    this.scheduledNotes = [];
  },

  // Called every frame to schedule audio ahead of time
  update() {
    if (!this.active || !this.era || !AudioEngine.ctx) return;
    if (this.era.finale && this.chart && Array.isArray(this.chart.musicBeatTimes)) {
      const now = AudioEngine.ctx.currentTime;
      const lookahead = 0.12;
      while (this.musicBeatIndex < this.chart.musicBeatTimes.length) {
        const event = this.chart.musicBeatTimes[this.musicBeatIndex];
        const when = this.songStartTime + event.time;
        if (when > now + lookahead) break;
        if (when >= now - 0.15) {
          const beatInterval = 60 / event.bpm;
          const step = event.step;
          // Exact beat click so the final level's falling notes and music
          // remain audibly locked together.
          AudioEngine.playBeatClick(this.era.instrument, when, !event.sub);
          // Pre-cutscene march and post-cutscene charge each get their own
          // motif, so the finale's music actually changes character at the
          // dragon reveal rather than just speeding up.
          const motif = (event.section === 'post' ? this.era.motifPost : this.era.motif) || this.era.motif;
          const scaleIndex = motif ? motif[step % motif.length] % this.era.scale.length : (step + Math.floor(step / 4)) % this.era.scale.length;
          this.era._activeBpm = event.bpm;
          this.era.density = event.section === 'post' ? 0.92 : 0.68;
          if (!event.sub) {
            // On-beat: full melody note plus bass/drums, same cadence as before.
            AudioEngine.playInstrument(this.era.scale[scaleIndex], beatInterval * 0.8, this.era.instrument, event.section === 'post' ? 0.28 : 0.2, when);
            if (step % 2 === 0) AudioEngine.playBass(this.era.bassFreq, beatInterval * 1.2, this.era.bassType, when);
            if (this.era.drums) {
              AudioEngine.playDrum(step % 2 === 0 ? 'kick' : 'snare', when);
              AudioEngine.playDrum('hihat', when);
            }
          } else {
            // Half-beat: a lighter melody hit so every falling note in the
            // charge section (which lands on half-beats too) has an
            // audible counterpart, plus a soft hat for groove.
            AudioEngine.playInstrument(this.era.scale[scaleIndex], beatInterval * 0.5, this.era.instrument, 0.14, when);
            if (this.era.drums) AudioEngine.playDrum('hihat', when);
          }
        }
        this.musicBeatIndex++;
      }
      const finalTime = this.chart.duration;
      if (this.getSongTime() > finalTime + 0.5) this.active = false;
      return;
    }
    const lookahead = 0.1; // schedule 100ms ahead
    const currentTime = AudioEngine.ctx.currentTime;

    const beatInterval = 60 / this.era.bpm;
    // 'fast' and 'funk' charts place falling notes on half-beats as well as
    // whole beats (see generateChart's patterns). The music used to only
    // ever play on whole beats, so those half-beat notes arrived with no
    // matching sound. Stepping the sequencer itself at the chart's finest
    // subdivision keeps every falling note lined up with an audible hit.
    const subdivision = (this.era.pattern === 'fast' || this.era.pattern === 'funk') ? 0.5 : 1;
    const stepInterval = beatInterval * subdivision;
    const motif = this.era.motif;

    // Schedule notes up to lookahead
    while (this.scheduledTime < currentTime + lookahead) {
      const t = this.scheduledTime;
      const step = this.beatIndex;
      const beatPos = step * subdivision;
      const onBeat = Number.isInteger(beatPos);

      // Get the note index relative to the song start
      const songTime = t - this.songStartTime;

      // Melody: cycle through this era's own short motif so each level has
      // a distinct, recognizable tune instead of every level walking the
      // scale the same generic way. Every step gets a melody hit (not just
      // whole beats), which is what keeps the half-beat notes in fast/funk
      // levels synced to something audible.
      const scaleIndex = motif ? motif[step % motif.length] % this.era.scale.length : (step + Math.floor(step / 4)) % this.era.scale.length;
      const melodyFreq = this.era.scale[scaleIndex];
      const melodyVol = onBeat ? 0.2 : 0.13;
      if (onBeat || this.era.density > 0.5) {
        AudioEngine.playInstrument(melodyFreq, stepInterval * 0.85, this.era.instrument, melodyVol, t);
      }

      // Bass and drums stay anchored to the real beat grid (not the finer
      // subdivision) so the groove underneath doesn't get busier than it
      // should just because the melody now fills in every half-beat.
      if (onBeat) {
        const beat = Math.round(beatPos);
        if (beat % 2 === 0) {
          AudioEngine.playBass(this.era.bassFreq, beatInterval * 1.5, this.era.bassType, t);
        }
        if (this.era.drums) {
          if (beat % 2 === 0) AudioEngine.playDrum('kick', t);
          if (beat % 2 === 1) AudioEngine.playDrum('snare', t);
          AudioEngine.playDrum('hihat', t);
        }
      } else if (this.era.drums && this.era.density > 0.6) {
        AudioEngine.playDrum('hihat', t);
      }

      this.scheduledTime += stepInterval;
      this.beatIndex++;

      // Stop if we've exceeded song duration
      if (songTime > this.chart.duration + 2) {
        this.active = false;
        break;
      }
    }
  },

  // Get current song time (relative to song start)
  getSongTime() {
    if (!this.songStartTime || !AudioEngine.ctx) return 0;
    return AudioEngine.ctx.currentTime - this.songStartTime;
  },
};

// ---------- CUSTOM AUDIO PLAYER ----------
// Plays a user-uploaded music file for custom levels, on the same
// START_DELAY lead-in timeline as the procedural MusicSequencer so
// note-spawn math works identically for both.
const CustomPlayer = {
  audioEl: null,
  active: false,
  started: false,
  isPaused: false,
  startPerf: 0,
  pausedElapsed: 0,
  analyser: null,
  sourceNode: null,
  frequencyData: null,
  beatPulse: 0,
  energyAverage: 0.012,
  lastBeatTime: -10,
  lastOnsetTime: -1,
  estimatedBeatInterval: 0.5,
  nextPredictedBeat: 0,
  isYouTube: false,

  start(era) {
    this.stop();
    this.isYouTube = !!getYouTubeVideoId(era.audioUrl || '');
    if (this.isYouTube) {
      this.active = true;
      this.started = true;
      YouTubePlayer.onEnded = () => {
        if (this.active && this.isYouTube) this.active = false;
      };
      this.isPaused = false;
      this.startPerf = performance.now();
      // IMPORTANT: use the dedicated gameplay player, not the editor player.
      // The editor overlay is hidden after a custom level is saved, and a hidden
      // editor iframe can stop advancing its playback clock in Android WebView.
      YouTubePlayer.load(era.audioUrl, 'game-youtube-player').then(() => {
        if (this.active && this.isYouTube) YouTubePlayer.play();
      }).catch((error) => {
        console.warn('YouTube playback unavailable:', error);
        this.active = false;
      });
      return;
    }
    this.audioEl = new Audio(era.audioUrl);
    this.audioEl.preload = 'auto';
    this.startPerf = performance.now();
    this.started = false;
    this.isPaused = false;
    this.active = true;
    this.beatPulse = 0;
    this.energyAverage = 0.012;
    this.lastBeatTime = -10;
    this.lastOnsetTime = -1;
    this.estimatedBeatInterval = 0.5;
    this.nextPredictedBeat = START_DELAY;
    try {
      AudioEngine.init();
      const ac = AudioEngine.ctx;
      if (ac && ac.createMediaElementSource) {
        this.sourceNode = ac.createMediaElementSource(this.audioEl);
        this.analyser = ac.createAnalyser();
        this.analyser.fftSize = 1024;
        this.analyser.smoothingTimeConstant = 0.35;
        this.frequencyData = new Uint8Array(this.analyser.frequencyBinCount);
        this.sourceNode.connect(this.analyser);
        this.analyser.connect(AudioEngine.musicGain || ac.destination);
      }
    } catch (error) {
      console.warn('Beat detector unavailable:', error);
      this.analyser = null;
      this.frequencyData = null;
    }
  },

  stop() {
    if (this.isYouTube && typeof YouTubePlayer !== 'undefined') YouTubePlayer.stop();
    this.isYouTube = false;
    if (this.audioEl) {
      try { this.audioEl.pause(); } catch (_error) {}
    }
    try { if (this.sourceNode) this.sourceNode.disconnect(); } catch (_error) {}
    try { if (this.analyser) this.analyser.disconnect(); } catch (_error) {}
    this.sourceNode = null;
    this.analyser = null;
    this.frequencyData = null;
    this.audioEl = null;
    this.active = false;
    this.started = false;
    this.isPaused = false;
    this.beatPulse = 0;
    this.lastOnsetTime = -1;
    this.estimatedBeatInterval = 0.5;
    this.nextPredictedBeat = 0;
  },

  pause() {
    if (!this.active || this.isPaused) return;
    this.isPaused = true;
    if (this.isYouTube) { YouTubePlayer.pause(); return; }
    if (this.started && this.audioEl) {
      this.audioEl.pause();
    } else {
      this.pausedElapsed = (performance.now() - this.startPerf) / 1000;
    }
  },

  resume() {
    if (!this.active || !this.isPaused) return;
    this.isPaused = false;
    if (this.isYouTube) { YouTubePlayer.play(); return; }
    if (this.started && this.audioEl) {
      this.audioEl.play().catch(() => {});
    } else {
      this.startPerf = performance.now() - this.pausedElapsed * 1000;
    }
  },

  update() {
    if (this.isYouTube) {
      if (this.active && !this.isPaused && YouTubePlayer.ended) { this.active = false; }
      this.beatPulse = 0;
      return;
    }
    if (!this.active || this.isPaused || !this.audioEl) {
      if (this.beatPulse > 0) this.beatPulse *= 0.88;
      return;
    }
    const elapsed = (performance.now() - this.startPerf) / 1000;
    if (!this.started && elapsed >= START_DELAY) {
      this.started = true;
      this.audioEl.currentTime = 0;
      this.audioEl.play().catch(() => {});
    }
    if (!this.started || !this.analyser || !this.frequencyData) return;

    this.analyser.getByteFrequencyData(this.frequencyData);
    // Focus on low frequencies where kicks/bass usually live.
    const bins = Math.min(18, this.frequencyData.length);
    let energy = 0;
    for (let i = 1; i < bins; i++) energy += this.frequencyData[i] / 255;
    energy /= Math.max(1, bins - 1);
    this.energyAverage = this.energyAverage * 0.92 + energy * 0.08;
    const now = this.audioEl.currentTime;
    const cooldown = 0.18;
    const threshold = Math.max(0.032, this.energyAverage * 1.30);
    const onset = energy > threshold && energy > this.energyAverage + 0.010 && now - this.lastBeatTime > cooldown;

    if (onset) {
      if (this.lastOnsetTime >= 0) {
        const interval = now - this.lastOnsetTime;
        // Ignore obvious half/double-time outliers and gently learn the song tempo.
        if (interval >= 0.28 && interval <= 1.20) {
          const candidate = Math.min(1.0, Math.max(0.32, interval));
          this.estimatedBeatInterval = this.estimatedBeatInterval * 0.72 + candidate * 0.28;
        }
      }
      this.lastOnsetTime = now;
      this.lastBeatTime = now;
      this.beatPulse = 1;
      this.nextPredictedBeat = now + this.estimatedBeatInterval;
    } else if (now >= this.nextPredictedBeat && this.lastOnsetTime >= 0) {
      // Keep the animation locked to the learned beat grid even when a kick is quiet.
      const missed = Math.max(1, Math.floor((now - this.nextPredictedBeat) / this.estimatedBeatInterval) + 1);
      this.nextPredictedBeat += missed * this.estimatedBeatInterval;
      this.lastBeatTime = now;
      this.beatPulse = 0.92;
    } else {
      // Frame-rate independent decay, so the pulse behaves consistently on fast/slow displays.
      this.beatPulse *= Math.pow(0.0005, 1 / 60);
    }
  },

  getBeatPulse() {
    return this.active ? this.beatPulse : 0;
  },

  getSongTime() {
    if (!this.active) return 0;
    if (this.isYouTube) {
      const ytTime = YouTubePlayer.getCurrentTime();
      // While the iframe is initializing, keep the gameplay clock moving rather
      // than freezing all custom notes at the hit line. Once YouTube reports a
      // real position, its clock becomes authoritative for timing.
      if (YouTubePlayer.ready) return START_DELAY + ytTime;
      return START_DELAY + Math.max(0, (performance.now() - this.startPerf) / 1000);
    }
    if (!this.started) {
      return this.isPaused ? this.pausedElapsed : (performance.now() - this.startPerf) / 1000;
    }
    return START_DELAY + (this.audioEl ? this.audioEl.currentTime : 0);
  },
};

// ---------- SONG DISPATCH ----------
// Routes playback calls to the procedural MusicSequencer for built-in
// eras, or to CustomPlayer for a player-made level with uploaded audio.
const Song = {
  mode: 'procedural',

  start(era, chart) {
    this.mode = era.custom ? 'custom' : 'procedural';
    if (this.mode === 'custom') {
      CustomPlayer.start(era);
    } else {
      MusicSequencer.start(era, chart);
    }
  },

  stop() {
    MusicSequencer.stop();
    CustomPlayer.stop();
  },

  update() {
    if (this.mode === 'custom') CustomPlayer.update();
    else MusicSequencer.update();
  },

  getBeatPulse() {
    return this.mode === 'custom' ? CustomPlayer.getBeatPulse() : 0;
  },

  getSongTime() {
    return this.mode === 'custom' ? CustomPlayer.getSongTime() : MusicSequencer.getSongTime();
  },

  pause() {
    if (this.mode === 'custom') {
      CustomPlayer.pause();
    } else if (AudioEngine.ctx && AudioEngine.ctx.state === 'running') {
      AudioEngine.ctx.suspend();
    }
  },

  resume() {
    if (this.mode === 'custom') {
      CustomPlayer.resume();
    } else if (AudioEngine.ctx && AudioEngine.ctx.state === 'suspended') {
      AudioEngine.ctx.resume();
    }
  },
};

// ---------- GAME STATE ----------
const GameState = {
  phase: 'title', // title, playing, levelComplete, gameOver, victory
  levelIndex: 0,
  score: 0,
  combo: 0,
  maxCombo: 0,
  hp: HP_MAX,
  perfects: 0,
  goods: 0,
  misses: 0,
  strayMisses: 0,
  missPenalty: 0, // escalating accuracy cost of misses so far this level
  totalNotes: 0,
  chart: null,
  notes: [],
  hitLaneFlash: [0, 0, 0, 0],
  particles: [],
  cameraShake: 0,
  totalScore: 0,
  totalPerfects: 0,
  levelsCompleted: 0,
  finaleCutscene: false,
  finaleCutsceneShown: false,
};

// ---------- CANVAS SETUP ----------
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let W = 0, H = 0, DPR = 1;

function resizeCanvas() {
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  W = window.innerWidth;
  H = window.innerHeight;
  canvas.width = W * DPR;
  canvas.height = H * DPR;
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';
  ctx.imageSmoothingEnabled = false;
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// ---------- PIXEL ART DRAWING HELPERS ----------
function pixelRect(x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.floor(x), Math.floor(y), Math.ceil(w), Math.ceil(h));
}

function pixelText(text, x, y, size, color, align) {
  ctx.font = size + 'px "Press Start 2P", monospace';
  ctx.textAlign = align || 'left';
  ctx.fillStyle = color;
  ctx.fillText(text, x, y);
}

// Draw a pixel-art building
function drawBuilding(x, y, w, h, color, lightColor, windowColor) {
  pixelRect(x, y, w, h, color);
  pixelRect(x - 4, y - 12, w + 8, 12, lightColor);
  pixelRect(x - 8, y - 12, 8, 4, color);
  const winSize = Math.max(3, Math.floor(w / 11));
  const winSpacing = Math.max(10, Math.floor(w / 3.5));
  for (let row = 0, wy = y + 8; wy < y + h - 8; wy += winSpacing, row++) {
    for (let col = 0, wx = x + 6; wx < x + w - 6; wx += winSpacing, col++) {
      // Deterministic pattern so windows do not flicker every frame.
      if ((row * 7 + col * 11 + Math.floor(w) + Math.floor(h)) % 10 > 2) {
        pixelRect(wx, wy, winSize, winSize, windowColor);
      }
    }
  }
}

const buildingImageCache = new Map();
function loadBuildingImage(src) {
  if (!src) return null;
  if (buildingImageCache.has(src)) return buildingImageCache.get(src);
  const img = new Image();
  img.decoding = 'async';
  img.src = src;
  buildingImageCache.set(src, img);
  return img;
}

function presetBuildingImage(kind) {
  if (kind === 'brick') {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="260" viewBox="0 0 160 260"><rect width="160" height="260" fill="#713f35"/><rect y="0" width="160" height="16" fill="#9d604d"/><g fill="#e7b65c"><rect x="18" y="30" width="22" height="14"/><rect x="68" y="30" width="22" height="14"/><rect x="118" y="30" width="22" height="14"/><rect x="18" y="72" width="22" height="14"/><rect x="68" y="72" width="22" height="14"/><rect x="118" y="72" width="22" height="14"/><rect x="18" y="114" width="22" height="14"/><rect x="68" y="114" width="22" height="14"/><rect x="118" y="114" width="22" height="14"/><rect x="18" y="156" width="22" height="14"/><rect x="68" y="156" width="22" height="14"/><rect x="118" y="156" width="22" height="14"/><rect x="18" y="198" width="22" height="14"/><rect x="68" y="198" width="22" height="14"/><rect x="118" y="198" width="22" height="14"/></g></svg>`);
  }
  if (kind === 'glass') {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="300" viewBox="0 0 160 300"><rect width="160" height="300" fill="#253b58"/><rect x="10" width="140" height="10" fill="#80c8d9"/><g fill="#91e2ef" opacity=".8"><rect x="20" y="28" width="28" height="20"/><rect x="66" y="28" width="28" height="20"/><rect x="112" y="28" width="28" height="20"/><rect x="20" y="70" width="28" height="20"/><rect x="66" y="70" width="28" height="20"/><rect x="112" y="70" width="28" height="20"/><rect x="20" y="112" width="28" height="20"/><rect x="66" y="112" width="28" height="20"/><rect x="112" y="112" width="28" height="20"/><rect x="20" y="154" width="28" height="20"/><rect x="66" y="154" width="28" height="20"/><rect x="112" y="154" width="28" height="20"/><rect x="20" y="196" width="28" height="20"/><rect x="66" y="196" width="28" height="20"/><rect x="112" y="196" width="28" height="20"/><rect x="20" y="238" width="28" height="20"/><rect x="66" y="238" width="28" height="20"/><rect x="112" y="238" width="28" height="20"/></g></svg>`);
  }
  return null;
}

function drawThemedBuilding(era, x, y, w, h, index) {
  const p = era.palette, type = era.backgroundType;
  if (type === 'market') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-5,y-10,w+10,10,p.buildingLight);
    pixelRect(x+w*.08,y+h*.2,w*.24,h*.18,p.accent); pixelRect(x+w*.68,y+h*.2,w*.24,h*.18,p.accent);
    pixelRect(x+w*.40,y+h*.55,w*.20,h*.45,'#2a1b17');
  } else if (type === 'riverside') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-4,y-14,w+8,14,'#765247');
    pixelRect(x+w*.12,y+h*.22,w*.20,h*.20,'#7aa8a4'); pixelRect(x+w*.42,y+h*.22,w*.20,h*.20,'#7aa8a4'); pixelRect(x+w*.72,y+h*.22,w*.16,h*.20,'#7aa8a4');
    pixelRect(x+w*.42,y+h*.58,w*.18,h*.42,'#2a2222');
  } else if (type === 'foundry') {
    pixelRect(x,y,w,h,p.building); pixelRect(x+w*.18,y-24,w*.64,24,p.buildingLight); pixelRect(x+w*.34,y-58,w*.24,34,p.buildingLight);
    pixelRect(x+w*.12,y+h*.28,w*.28,h*.10,p.accent); pixelRect(x+w*.60,y+h*.28,w*.28,h*.10,p.accent); pixelRect(x+w*.40,y+h*.62,w*.20,h*.38,'#1a1414');
  } else if (type === 'merchant') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-6,y-12,w+12,12,p.buildingLight);
    pixelRect(x+w*.08,y+h*.20,w*.25,h*.24,p.buildingLight); pixelRect(x+w*.67,y+h*.20,w*.25,h*.24,p.buildingLight); pixelRect(x+w*.38,y+h*.56,w*.24,h*.44,'#342218');
    pixelRect(x+w*.12,y+h*.48,w*.76,5,p.accent);
  } else if (type === 'harbor') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-5,y-10,w+10,10,p.buildingLight); pixelRect(x+w*.12,y+h*.22,w*.25,h*.18,p.accent); pixelRect(x+w*.62,y+h*.22,w*.25,h*.18,p.accent); pixelRect(x+w*.40,y+h*.56,w*.20,h*.44,'#172126');
  } else if (type === 'noble') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-8,y-14,w+16,14,p.buildingLight);
    for(let k=0;k<3;k++){const cx=x+w*(.18+k*.32); pixelRect(cx,y+h*.18,w*.18,h*.25,p.accent); pixelRect(cx+w*.04,y+h*.22,w*.10,h*.16,p.buildingLight);}
    pixelRect(x+w*.38,y+h*.58,w*.24,h*.42,'#252a32');
  } else if (type === 'gardens') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-6,y-10,w+12,10,p.buildingLight);
    pixelRect(x+w*.12,y+h*.20,w*.20,h*.18,p.accent); pixelRect(x+w*.68,y+h*.20,w*.20,h*.18,p.accent); pixelRect(x+w*.40,y+h*.55,w*.20,h*.45,'#213022');
    for(let k=0;k<3;k++){ctx.fillStyle='#476449';ctx.beginPath();ctx.arc(x+w*(.2+k*.3),y-8,14,0,Math.PI*2);ctx.fill();}
  } else if (type === 'court') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-8,y-16,w+16,16,p.buildingLight); pixelRect(x+w*.1,y+h*.18,w*.18,h*.24,p.accent); pixelRect(x+w*.41,y+h*.18,w*.18,h*.24,p.accent); pixelRect(x+w*.72,y+h*.18,w*.18,h*.24,p.accent); pixelRect(x+w*.38,y+h*.55,w*.24,h*.45,'#30243a');
  } else if (type === 'orbit') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-6,y-12,w+12,12,p.buildingLight); pixelRect(x+w*.12,y+h*.20,w*.30,h*.25,p.buildingLight); pixelRect(x+w*.58,y+h*.20,w*.30,h*.25,p.buildingLight); pixelRect(x+w*.36,y+h*.60,w*.28,h*.40,'#0e1626');
  } else if (type === 'space') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-5,y-10,w+10,10,p.buildingLight);
    for(let r=0;r<3;r++) for(let c=0;c<3;c++) pixelRect(x+w*.12+c*w*.27,y+h*(.18+r*.24),w*.16,h*.12,p.accent);
    pixelRect(x+w*.38,y+h*.72,w*.24,h*.28,'#071018');
  } else if (type === 'ballroom') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-7,y-12,w+14,12,p.buildingLight);
    for(let k=0;k<3;k++){ const cx=x+w*(.18+k*.30); pixelRect(cx,y+h*.20,w*.18,h*.28,p.accent); pixelRect(cx+w*.04,y+h*.25,w*.10,h*.18,p.buildingLight); }
    pixelRect(x+w*.38,y+h*.60,w*.24,h*.40,'#24172d');
  } else if (type === 'crystal') {
    pixelRect(x,y,w,h,p.building); pixelRect(x-5,y-10,w+10,10,p.buildingLight);
    for(let k=0;k<4;k++){ const cx=x+w*(.12+k*.25); pixelRect(cx,y+h*(.22+(k%2)*.12),w*.12,h*.42,p.accent); pixelRect(cx+w*.04,y+h*.12,w*.05,h*.20,p.buildingLight); }
    pixelRect(x+w*.40,y+h*.65,w*.20,h*.35,'#06171d');
  } else {
    drawBuilding(x,y,w,h,p.building,p.buildingLight,p.accent);
  }
}

function drawBuildingVisual(settings, x, y, w, h, palette, index) {
  const mode = settings.imageMode || 'procedural';
  const src = mode === 'custom' ? settings.imageData : presetBuildingImage(mode);
  const img = src ? loadBuildingImage(src) : null;
  if (img && img.complete && img.naturalWidth) {
    const scale = Math.max(0.25, Number(settings.imageScale || 100) / 100);
    const dw = w * scale, dh = h * scale;
    ctx.drawImage(img, x - (dw - w) / 2, y - (dh - h), dw, dh);
  } else {
    drawBuilding(x, y, w, h, palette.building, palette.buildingLight, palette.accent);
  }
}

// Draw a star
function drawStar(x, y, brightness) {
  pixelRect(x, y, 2, 2, `rgba(255, 255, 255, ${brightness})`);
  pixelRect(x - 1, y + 1, 4, 1, `rgba(255, 255, 255, ${brightness * 0.5})`);
  pixelRect(x + 1, y - 1, 1, 4, `rgba(255, 255, 255, ${brightness * 0.5})`);
}

// ---------- BACKGROUND RENDERING ----------
let bgStars = [];
let bgOffset = 0;

function initStars(count) {
  bgStars = [];
  for (let i = 0; i < count; i++) {
    bgStars.push({
      x: Math.random() * W,
      y: Math.random() * H * 0.6,
      brightness: 0.3 + Math.random() * 0.7,
      twinkle: Math.random() * Math.PI * 2,
      speed: 0.5 + Math.random() * 1.5,
    });
  }
}

function drawFinaleScene(era, songTime, cutscene) {
  const p = era.palette;
  const groundY = getHitLineY();
  const cutStart = era.cutsceneAt || songTime;
  const duration = Math.max(0.1, era.cutsceneDuration || 5);
  const cutEnd = cutStart + duration;
  const inCutscene = !!cutscene;

  // The finale is an outdoor ruin, not the old throne-room interior. The
  // landscape stays intentionally quiet and imposing: a huge blood moon,
  // motionless hills, dark forest walls, and a river winding down the right.
  drawFinaleLandscape(era, songTime, groundY);

  if (!inCutscene) {
    // Keep the playable finale readable after the reveal.
    drawFinaleRubble(W * 0.5, groundY * 0.72, W * 0.62, groundY * 0.30, 0.25);
    drawGuardianDragon(W * 0.52, groundY * 0.72, Math.min(groundY * 0.44, W * 0.42), songTime, 0.92);
    return;
  }

  const progress = Math.max(0, Math.min(1, (songTime - cutStart) / duration));

  // Four cinematic phases:
  // 0-.20: castle appears intact and begins shaking
  // .20-.42: violent explosion
  // .42-.76: smoke and embers swallow the ruins
  // .76-1.0: smoke clears and the detailed dragon rises on the rubble
  const shake = progress < 0.42 ? Math.sin(songTime * 70) * Math.max(0, progress / 0.42) * 8 : 0;
  const castleX = W * 0.5 + shake;
  const castleBase = groundY * 0.72;
  const intact = Math.max(0, 1 - progress / 0.42);

  if (progress < 0.44) {
    drawFinaleCastle(castleX, castleBase, Math.min(W * 0.42, groundY * 0.55), intact);
  }

  // Explosion flash and expanding fireball.
  if (progress >= 0.18 && progress < 0.55) {
    const e = Math.min(1, (progress - 0.18) / 0.24);
    const fade = progress > 0.42 ? Math.max(0, 1 - (progress - 0.42) / 0.13) : 1;
    ctx.save();
    ctx.globalAlpha = fade;
    const r = Math.max(20, W * (0.08 + e * 0.23));
    const glow = ctx.createRadialGradient(W * .5, castleBase - groundY * .25, 4, W * .5, castleBase - groundY * .25, r);
    glow.addColorStop(0, 'rgba(255,244,170,.95)');
    glow.addColorStop(.22, 'rgba(255,175,45,.9)');
    glow.addColorStop(.62, 'rgba(216,60,24,.55)');
    glow.addColorStop(1, 'rgba(80,10,8,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(W*.5-r, castleBase-groundY*.25-r, r*2, r*2);
    for (let i=0;i<28;i++) {
      const a = i * 2.399 + songTime * 2;
      const d = (0.15 + ((i*37)%100)/100 * .85) * r;
      const x = W*.5 + Math.cos(a)*d;
      const y = castleBase-groundY*.25 + Math.sin(a)*d*.72;
      const sz = 2 + ((i*13)%7);
      pixelRect(x, y, sz, sz, i%3 ? '#e75a24' : '#ffd36a');
    }
    ctx.restore();
  }

  // Burning rubble appears beneath the smoke as the castle collapses.
  if (progress >= 0.34) {
    const rubbleAlpha = Math.min(1, (progress - .34) / .25);
    drawFinaleRubble(W*.5, castleBase, W*.62, groundY*.30, rubbleAlpha);
  }

  // Thick layered smoke rolls upward, then rapidly thins for the reveal.
  if (progress >= 0.30 && progress < 0.88) {
    const smokeIn = Math.min(1, (progress - .30) / .20);
    const smokeOut = progress > .66 ? Math.max(0, 1 - (progress - .66) / .22) : 1;
    const smokeAlpha = smokeIn * smokeOut;
    ctx.save();
    ctx.globalAlpha = smokeAlpha;
    for (let i=0;i<18;i++) {
      const phase = i * 1.73;
      const x = W*.5 + Math.sin(phase + songTime*.55) * (W*.10 + i*4) + ((i%3)-1)*W*.07;
      const y = castleBase - groundY*.12 - i*groundY*.035 - Math.abs(Math.sin(phase))*groundY*.06;
      const rx = W*(.07 + (i%4)*.018);
      const ry = groundY*(.06 + (i%3)*.012);
      ctx.fillStyle = i%3===0 ? 'rgba(28,22,22,.92)' : 'rgba(50,35,31,.86)';
      ctx.beginPath(); ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2); ctx.fill();
    }
    ctx.restore();
  }

  // Final reveal: a large, detailed dragon rises from the burning ruins in
  // front of the blood moon. It stays still enough to feel monumental, while
  // the subtle idle animation prevents it from looking like a black blob.
  if (progress >= 0.72) {
    const reveal = Math.min(1, (progress - .72) / .28);
    const eased = Math.min(1, easeOutBack(reveal));
    const dragonScale = Math.min(groundY * .47, W * .43) * (.72 + .28*eased);
    const rise = (1-eased) * groundY * .10;
    drawFinaleRubble(W*.5, castleBase, W*.62, groundY*.30, 1);
    drawGuardianDragon(W*.52, castleBase, dragonScale, songTime, reveal);
    drawDragonEmbers(W*.52, castleBase, dragonScale, songTime, reveal);
  }

  // Cinematic title card.
  ctx.save();
  const titleAlpha = progress < .15 ? 1-progress/.15 : progress > .78 ? Math.max(0,1-(progress-.78)/.22) : .8;
  ctx.globalAlpha = titleAlpha;
  pixelRect(W*.16,H*.055,W*.68,H*.09,'rgba(10,5,5,.72)');
  ctx.strokeStyle = p.accent; ctx.lineWidth=2; ctx.strokeRect(W*.16,H*.055,W*.68,H*.09);
  pixelText(progress < .48 ? 'THE CASTLE FALLS' : 'THE DRAGON RISES', W/2,H*.095,Math.min(22,W/25),'#ffd77a','center');
  ctx.restore();
}

function drawFinaleLandscape(era, songTime, groundY) {
  const W2 = W, H2 = H;
  const sky = ctx.createLinearGradient(0,0,0,groundY);
  sky.addColorStop(0,'#090407'); sky.addColorStop(.55,'#2a080c'); sky.addColorStop(1,'#4b1112');
  ctx.fillStyle=sky; ctx.fillRect(0,0,W2,groundY);

  // Blood moon.
  const mx=W2*.72, my=groundY*.25, mr=Math.min(W2,groundY)*.18;
  ctx.fillStyle='rgba(120,0,12,.22)'; ctx.beginPath(); ctx.arc(mx,my,mr*1.28,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#a51219'; ctx.beginPath(); ctx.arc(mx,my,mr,0,Math.PI*2); ctx.fill();
  ctx.fillStyle='#c52a29'; ctx.globalAlpha=.55;
  for(let i=0;i<16;i++){ const x=mx+(Math.sin(i*4.2)*.65)*mr, y=my+(Math.cos(i*2.7)*.65)*mr; ctx.beginPath(); ctx.arc(x,y,2+i%5,0,Math.PI*2); ctx.fill(); }
  ctx.globalAlpha=1;

  // Motionless distant hills.
  function hill(points, color){ ctx.fillStyle=color; ctx.beginPath(); points.forEach(([x,y],i)=>i?ctx.lineTo(x,y):ctx.moveTo(x,y)); ctx.lineTo(W2,groundY);ctx.lineTo(0,groundY);ctx.closePath();ctx.fill(); }
  hill([[0,groundY*.54],[W2*.12,groundY*.43],[W2*.25,groundY*.55],[W2*.38,groundY*.40],[W2*.53,groundY*.53],[W2*.67,groundY*.42],[W2*.82,groundY*.52],[W2,groundY*.38]], '#160d13');
  hill([[0,groundY*.67],[W2*.18,groundY*.55],[W2*.34,groundY*.65],[W2*.5,groundY*.50],[W2*.66,groundY*.64],[W2*.84,groundY*.51],[W2,groundY*.63]], '#0c0a10');

  // River on the right side, winding from the hills toward the foreground.
  ctx.fillStyle='#171b24'; ctx.beginPath();
  ctx.moveTo(W2*.78,groundY*.43); ctx.bezierCurveTo(W2*.72,groundY*.55,W2*.91,groundY*.64,W2*.78,groundY*.78);
  ctx.bezierCurveTo(W2*.68,groundY*.88,W2*.87,groundY*.95,W2*.72,groundY);
  ctx.lineTo(W2,groundY);ctx.lineTo(W2,groundY*.38);ctx.closePath();ctx.fill();
  ctx.strokeStyle='rgba(150,44,48,.42)';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(W2*.79,groundY*.46);ctx.bezierCurveTo(W2*.74,groundY*.59,W2*.9,groundY*.66,W2*.79,groundY*.79);ctx.bezierCurveTo(W2*.71,groundY*.88,W2*.84,groundY*.95,W2*.75,groundY);ctx.stroke();

  // Dark forests framing both sides.
  function trees(side){
    for(let i=0;i<13;i++){
      const x=side<0 ? i*(W2*.055)-10 : W2-i*(W2*.055)+10;
      const h=groundY*(.16+((i*17)%9)/30);
      ctx.fillStyle=i%3===0?'#050609':'#08070b';
      pixelRect(x-3,groundY-h*.42,6,h*.48,'#09070a');
      for(let j=0;j<4;j++){ const yy=groundY-h+j*h*.12; const ww=(j+1)*W2*.018; ctx.beginPath();ctx.moveTo(x,yy-h*.26);ctx.lineTo(x-ww,yy);ctx.lineTo(x+ww,yy);ctx.closePath();ctx.fill(); }
    }
  }
  trees(-1); trees(1);

  // Ground / foreground.
  pixelRect(0,groundY,W2,H2-groundY,'#09070a');
  pixelRect(0,groundY-2,W2,3,'#351115');
}

function drawFinaleCastle(cx, baseY, s, alpha) {
  ctx.save(); ctx.globalAlpha=alpha;
  const bw=s*.42, bh=s*.52;
  ctx.fillStyle='#241517'; ctx.fillRect(cx-bw/2,baseY-bh,bw,bh);
  for(const side of [-1,1]){
    const tx=cx+side*bw*.34, th=bh*.72, tw=bw*.20;
    ctx.fillStyle='#171015';ctx.fillRect(tx-tw/2,baseY-th,tw,th);
    ctx.beginPath();ctx.moveTo(tx-tw*.65,baseY-th);ctx.lineTo(tx,baseY-th-s*.18);ctx.lineTo(tx+tw*.65,baseY-th);ctx.closePath();ctx.fill();
  }
  ctx.beginPath();ctx.moveTo(cx-bw*.22,baseY-bh);ctx.lineTo(cx,baseY-bh-s*.22);ctx.lineTo(cx+bw*.22,baseY-bh);ctx.closePath();ctx.fill();
  for(let y=baseY-bh*.75;y<baseY-bh*.1;y+=s*.11){ for(let x=cx-bw*.32;x<cx+bw*.32;x+=s*.12){ pixelRect(x,y,Math.max(3,s*.025),Math.max(3,s*.04), '#6f2a1f'); } }
  ctx.restore();
}

function drawFinaleRubble(cx, baseY, w, h, alpha) {
  ctx.save();ctx.globalAlpha=alpha;
  for(let i=0;i<42;i++){
    const x=cx-w/2+(i*83%1000)/1000*w;
    const y=baseY-(i*37%100)/100*h;
    const rw=6+(i*11%18), rh=4+(i*7%15);
    ctx.fillStyle=i%4===0?'#8d321f':i%3===0?'#4a2520':'#211517';
    ctx.fillRect(x,y,rw,rh);
  }
  ctx.fillStyle='rgba(255,94,30,.7)';
  for(let i=0;i<10;i++){ const x=cx-w*.4+(i*71%100)/100*w; const y=baseY-h*.2-(i%4)*5; ctx.fillRect(x,y,3+(i%3)*2,2+(i%2)*2); }
  ctx.restore();
}

function drawDragonEmbers(cx, baseY, s, t, alpha) {
  ctx.save();ctx.globalAlpha=alpha*.8;
  for(let i=0;i<18;i++){
    const a=i*2.1, r=s*(.25+((i*13)%70)/100);
    const x=cx+Math.cos(a+t*.7)*r, y=baseY-s*.2-Math.abs(Math.sin(a+t*.5))*s*.55;
    pixelRect(x,y,2+(i%3),2+(i%2),i%3?'#e55a26':'#ffd66b');
  }
  ctx.restore();
}

function easeOutBack(x) {
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}

// ---------- FINALE TOWER + GUARDIAN DRAGON ----------
// The dragon is built as a small fixed-resolution pixel-art sprite (168x104
// logical pixels) drawn once per frame onto an offscreen canvas with flat
// polygons only -- no curves, no smoothing. The caller then blits that
// offscreen canvas onto the main canvas scaled way up with image smoothing
// disabled, which is what turns clean vector shapes into the chunky,
// hand-pixeled NES look of the reference artwork, at whatever size `s`
// calls for. Re-rendering the low-res sprite every frame (rather than
// caching a static image) is what lets it stay alive: wings flutter, the
// tail wags, it blinks, and it periodically winds up and breathes fire.
function drawFinaleTower(cx, cy, s) {
  const towerCream = '#e7cdb2', towerShade = '#c4a480', towerDark = '#1c100c';
  const towerW = s * 0.30;
  const x0 = cx - towerW / 2, x1 = cx + towerW / 2;
  const top = cy - s * 1.02, base = cy + s * 0.62;

  pixelRect(x0, top, towerW, base - top, towerCream);
  pixelRect(x0, top, towerW * 0.28, base - top, towerShade);

  // Spire.
  const spireTop = top - s * 0.30;
  ctx.fillStyle = towerCream;
  ctx.beginPath(); ctx.moveTo(x0 - 6, top); ctx.lineTo(x1 + 6, top); ctx.lineTo(cx, spireTop); ctx.closePath(); ctx.fill();
  ctx.fillStyle = towerShade;
  ctx.beginPath(); ctx.moveTo(cx, top); ctx.lineTo(x1 + 6, top); ctx.lineTo(cx, spireTop); ctx.closePath(); ctx.fill();
  pixelRect(cx - 3, spireTop - 14, 6, 14, towerCream);
  ctx.fillStyle = towerCream;
  ctx.beginPath(); ctx.arc(cx, spireTop - 15, 5, 0, Math.PI * 2); ctx.fill();

  // Corner pinnacles.
  for (const side of [-1, 1]) {
    const px = cx + side * (towerW / 2 + 6);
    ctx.fillStyle = towerCream;
    ctx.beginPath(); ctx.moveTo(px - 8, top); ctx.lineTo(px + 8, top); ctx.lineTo(px, top - 24); ctx.closePath(); ctx.fill();
  }

  // Tall pointed window.
  const winW = towerW * 0.42, wx0 = cx - winW / 2, wcx = cx;
  const winTop = top + s * 0.18, winBot = top + s * 0.44;
  const domeH = winW / 2;
  ctx.fillStyle = towerDark;
  ctx.beginPath(); ctx.arc(wcx, winTop + domeH, winW / 2, Math.PI, 0); ctx.rect(wx0, winTop + domeH, winW, winBot - (winTop + domeH)); ctx.fill();

  // Lower blind arches.
  for (let i = 0; i < 3; i++) {
    const ax0 = x0 + towerW * 0.12 + i * towerW * 0.28, aw = towerW * 0.2;
    const ay0 = base - s * 0.30, ay1 = base - s * 0.06;
    const adome = aw / 2;
    ctx.fillStyle = towerShade;
    ctx.beginPath(); ctx.arc(ax0 + aw / 2, ay0 + adome, aw / 2, Math.PI, 0); ctx.rect(ax0, ay0 + adome, aw, ay1 - (ay0 + adome)); ctx.fill();
  }

  // Base plinth.
  pixelRect(x0 - 10, base, towerW + 20, s * 0.08, towerShade);
}

// A dedicated small offscreen canvas the dragon sprite is redrawn onto each
// frame. Kept at a fixed logical resolution regardless of on-screen size --
// that fixed low resolution is exactly what produces the chunky pixel look
// once it's scaled up, the same way a real NES sprite looks blocky no
// matter how large a TV it's played on.
let _dragonSpriteCanvas = null;
function getDragonSpriteCanvas() {
  if (!_dragonSpriteCanvas) {
    _dragonSpriteCanvas = document.createElement('canvas');
    _dragonSpriteCanvas.width = 168;
    _dragonSpriteCanvas.height = 104;
  }
  return _dragonSpriteCanvas;
}

// Draws the dragon into the small offscreen canvas using only flat
// polygons (no bezier/catmull-rom smoothing anywhere) so every edge lands
// on a hard corner, matching a hand-pixeled sprite rather than a smooth
// vector illustration. `anim` carries the small per-frame offsets that
// keep the guardian feeling alive. Returns the mouth position (in the same
// 168x104 sprite space) so the caller can anchor the fire breath there.
function renderDragonSprite(octx, anim) {
  const K = '#0b0708', D = '#3a1516', LG = '#8f3c2d', OR = '#d46a2b',
        BK = '#090507', CR = '#e9c7a1', EY = '#ffcf62';

  octx.clearRect(0, 0, 168, 104);
  octx.imageSmoothingEnabled = false;

  function poly(pts, color) {
    octx.fillStyle = color;
    octx.beginPath();
    pts.forEach(([x, y], i) => i === 0 ? octx.moveTo(x, y) : octx.lineTo(x, y));
    octx.closePath();
    octx.fill();
  }
  // A thick "ribbon" path built from a short chain of straight segments --
  // used for the tail and neck, deliberately with no curve smoothing.
  function thickPath(pts, w0, w1, color) {
    const n = pts.length, left = [], right = [];
    for (let i = 0; i < n; i++) {
      const [x, y] = pts[i];
      let dx, dy;
      if (i === 0) { dx = pts[1][0] - x; dy = pts[1][1] - y; }
      else if (i === n - 1) { dx = x - pts[i - 1][0]; dy = y - pts[i - 1][1]; }
      else { dx = pts[i + 1][0] - pts[i - 1][0]; dy = pts[i + 1][1] - pts[i - 1][1]; }
      const L = Math.hypot(dx, dy) || 1;
      const nx = -dy / L, ny = dx / L;
      const t = i / (n - 1), w = w0 + (w1 - w0) * t;
      left.push([x + nx * w, y + ny * w]);
      right.push([x - nx * w, y - ny * w]);
    }
    poly(left.concat(right.reverse()), color);
  }

  const { tailWag, wingLift, headTilt, blink, jawOpen } = anim;

  // ---- Tail: sweeps from the hip along the floor and curls up into a
  // small forked tip, matching the reference's coiled tail. ----
  const tail = [[80,78],[58,82+tailWag],[38,80+tailWag*1.4],[22,68+tailWag*1.6],[15,50+tailWag],[19,34],[30,26],[38,28]];
  thickPath(tail, 10, 3, K);
  thickPath(tail.slice(0, -1), 7, 3, D);
  poly([[30,26],[36,20],[40,26]], K);
  poly([[31,26],[35,22],[38,26]], D);

  // ---- Body ----
  const body = [[76,84],[58,76],[52,60],[56,44],[70,32],[90,26],[112,28],[126,38],[130,54],[124,70],[110,82],[94,86]];
  poly(body, K);
  const bodyIn = [[76,81],[61,74],[56,60],[59,46],[72,35],[90,29],[110,31],[123,40],[127,53],[121,68],[108,79],[95,83]];
  poly(bodyIn, D);
  octx.strokeStyle = LG; octx.lineWidth = 2;
  octx.beginPath();
  [[60,70],[57,58],[62,46],[74,36],[90,31]].forEach(([x,y],i) => i === 0 ? octx.moveTo(x,y) : octx.lineTo(x,y));
  octx.stroke();
  [[70,74],[82,80],[96,83],[108,80]].forEach(([bx,by]) => {
    poly([[bx-4,by-3],[bx+4,by-3],[bx+3,by+3],[bx-3,by+3]], LG);
  });

  // ---- Scalloped back ridge, echoing the reference's jagged spine ----
  const ridgeBase = [[72,30],[80,22],[90,18],[100,16],[110,17],[119,22],[126,30]];
  for (let i = 0; i < ridgeBase.length - 1; i++) {
    const [x0,y0] = ridgeBase[i], [x1,y1] = ridgeBase[i+1];
    const mx = (x0+x1)/2, my = (y0+y1)/2 - 10 - wingLift*2;
    poly([[x0,y0],[mx,my],[x1,y1],[(x0+x1)/2,(y0+y1)/2+4]], K);
    poly([[x0+1.2,y0-1],[mx,my+4.5],[x1-1.2,y1-1],[(x0+x1)/2,(y0+y1)/2+1]], D);
  }

  // ---- Wing: black membrane with an orange diamond scale pattern, the
  // signature look of the reference art. A gentle wingLift flutters the
  // whole shape a few pixels each cycle. ----
  const wl = wingLift;
  const wingOuter = [[80,34],[86,16-wl],[100,8-wl*1.4],[114,10-wl],[122,20],[120,36],[112,50],[100,56],[88,50]];
  poly(wingOuter, K);
  const wingIn = [[81,33],[87,18-wl],[100,11-wl*1.3],[112,13-wl],[119,21],[117,35],[110,47],[100,52],[90,47]];
  poly(wingIn, BK);
  octx.save();
  octx.beginPath();
  wingIn.forEach(([x,y],i) => i === 0 ? octx.moveTo(x,y) : octx.lineTo(x,y));
  octx.closePath();
  octx.clip();
  octx.fillStyle = OR;
  for (let row = 0, yy = 6 - wl; yy < 60; row++, yy += 6) {
    const off = row % 2 ? 3 : 0;
    for (let xx = 78 - off; xx < 126; xx += 6) {
      octx.beginPath();
      octx.moveTo(xx, yy-3); octx.lineTo(xx+3, yy); octx.lineTo(xx, yy+3); octx.lineTo(xx-3, yy);
      octx.closePath(); octx.fill();
    }
  }
  octx.restore();
  octx.strokeStyle = D; octx.lineWidth = 3;
  octx.beginPath(); octx.moveTo(84,30); octx.lineTo(100, 14-wl); octx.stroke();
  octx.lineWidth = 2;
  octx.beginPath(); octx.moveTo(84,30); octx.lineTo(96,52); octx.stroke();

  // ---- Far wing: a pale sliver peeking out behind the near wing/neck,
  // like the second wing catching the light in the reference image. ----
  poly([[120,40],[124,22-wl],[132,12-wl],[142,14-wl],[146,26],[140,40],[144,48],[132,46]], K);
  poly([[121,39],[125,23-wl],[132,15-wl],[140,17-wl],[144,26],[139,38],[142,46],[133,44]], CR);

  // ---- Legs ----
  function leg(x, y, w, h) {
    poly([[x-w/2-1,y-2],[x+w/2+1,y-2],[x+w/2+2,y+h],[x-w/2-2,y+h]], K);
    poly([[x-w/2,y-1],[x+w/2,y-1],[x+w/2+1,y+h-1],[x-w/2-1,y+h-1]], D);
    const tw = w/3;
    for (let i = 0; i < 3; i++) {
      const tx = x - w/2 + i*tw;
      poly([[tx,y+h-1],[tx+tw*0.7,y+h-1],[tx+tw*0.5,y+h+4]], CR);
    }
  }
  leg(70,80,14,14);
  leg(104,82,16,16);

  // ---- Neck + head, tilting a couple pixels on a slow watch cycle ----
  const hx = headTilt;
  const neck = [[122,44],[130,34],[136+hx,24+Math.abs(hx)*0.3]];
  thickPath(neck, 11, 9, K);
  thickPath(neck, 8, 6.5, D);

  const head = [[128+hx,18],[136+hx,8],[140+hx,4],[144+hx,10],[142+hx,16],[150+hx,18],[158+hx,26],[160+hx,34],[154+hx,42],[146+hx,46],[138+hx,46],[130+hx,40],[126+hx,30]];
  poly(head, K);
  const headIn = [[129+hx,19],[136+hx,11],[140+hx,7],[142+hx,11],[140+hx,16],[148+hx,19],[155+hx,26],[157+hx,34],[152+hx,40],[146+hx,43],[139+hx,43],[132+hx,38],[128+hx,30]];
  poly(headIn, D);
  poly([[138+hx,8],[136+hx,-2],[144+hx,9]], K);
  poly([[138+hx,7],[137+hx,1],[142+hx,8]], CR);

  // Jaw drops open as jawOpen ramps toward 1 during the fire-breath cycle.
  const jd = jawOpen * 10;
  octx.strokeStyle = K; octx.lineWidth = 3;
  octx.beginPath();
  [[130+hx,38],[140+hx,40+jd],[150+hx,40+jd],[156+hx,36+jd*0.6]].forEach(([x,y],i) => i === 0 ? octx.moveTo(x,y) : octx.lineTo(x,y));
  octx.stroke();
  [[134,40],[141,41],[148,41]].forEach(([jx,jy]) => {
    poly([[jx+hx,jy+jd*0.5],[jx+4+hx,jy+jd*0.5],[jx+2+hx,jy+5+jd*0.5]], CR);
  });
  poly([[150+hx,40+jd],[148+hx,50+jd],[153+hx,42+jd]], CR);

  // Eye, with a warm glow and a periodic blink.
  const eyeH = 3 * blink;
  octx.fillStyle = K;
  octx.beginPath(); octx.ellipse(144+hx,23,3,3,0,0,Math.PI*2); octx.fill();
  octx.fillStyle = EY;
  octx.beginPath(); octx.ellipse(144+hx,23,2,eyeH,0,0,Math.PI*2); octx.fill();
  octx.fillStyle = K;
  octx.beginPath(); octx.ellipse(156+hx,30,1,1,0,0,Math.PI*2); octx.fill();

  // Extra scale plates and facial ridges make the dragon read as a creature
  // with armor-like detail instead of a single dark silhouette.
  for (let row=0; row<4; row++) {
    for (let col=0; col<5-row; col++) {
      const sx=82+col*8+row*4, sy=49+row*7;
      poly([[sx,sy],[sx+4,sy-3],[sx+8,sy],[sx+5,sy+5],[sx+1,sy+5]], row%2 ? LG : OR);
    }
  }
  for (let i=0;i<4;i++) {
    poly([[132+hx+i*5,15+i*2],[136+hx+i*5,11+i*2],[137+hx+i*5,17+i*2]], K);
  }
  octx.strokeStyle = OR; octx.lineWidth = 1.5;
  octx.beginPath(); octx.moveTo(136+hx,29); octx.lineTo(151+hx,27); octx.lineTo(157+hx,31); octx.stroke();

  return { mouthX: 156 + hx, mouthY: 40 + jd * 0.6 };
}

// A blocky, flickering cone of fire breathed from the mouth. Coordinates
// are snapped to a grid sized to match the sprite's own pixel scale, so
// the flame reads as more chunky pixel art rather than a smooth particle
// effect that would clash with the rest of the dragon.
function drawDragonFireBreath(mx, my, angle, pixelScale, strength, t) {
  if (strength <= 0.01) return;
  const unit = Math.max(2, pixelScale * 3.2);
  const count = Math.round(8 + strength * 16);
  const dx = Math.cos(angle), dy = Math.sin(angle);
  const nx = -dy, ny = dx;
  const colors = ['#fff3b0', '#ffcf5c', '#f79a3a', '#e2611f', '#8f2a12'];
  for (let i = 0; i < count; i++) {
    const tt = i / count;
    const dist = tt * strength * 24 * unit;
    const spread = (0.12 + tt * 0.7) * unit * 2.4;
    const flick = Math.sin(t * 30 + i * 1.7) * 0.5 + 0.5;
    const wob = Math.sin(t * 16 + i * 2.3) * spread * 0.4;
    const cIdx = Math.min(colors.length - 1, Math.floor(tt * (colors.length - 1) + flick * 0.5));
    const px = mx + dx * dist + nx * wob;
    const py = my + dy * dist + ny * wob;
    const size = unit * (1.3 - tt * 0.5) * (0.8 + flick * 0.35);
    ctx.fillStyle = colors[cIdx];
    ctx.fillRect(Math.round(px / unit) * unit - size / 2, Math.round(py / unit) * unit - size / 2, size, size);
  }
  // A few embers drifting up off the flame for extra life.
  ctx.fillStyle = colors[1];
  for (let i = 0; i < 3; i++) {
    const ex = mx + dx * strength * 14 * unit + Math.sin(t * 4 + i * 2) * unit * 2.5;
    const ey = my + dy * strength * 14 * unit - ((t * 24 + i * 17) % (unit * 9));
    ctx.fillRect(Math.round(ex / unit) * unit, Math.round(ey / unit) * unit, unit * 0.6, unit * 0.6);
  }
}

function drawGuardianDragon(cx, cy, s, t, alpha) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.imageSmoothingEnabled = false;

  // Several independent, slow cycles keep the guardian feeling alive: a
  // gentle breathing bob, a wagging tail, a fluttering wing, and a head
  // that slowly turns to watch the room and blinks every few seconds.
  const breathe = Math.sin(t * 1.3) * s * 0.012;
  const tailWag = Math.sin(t * 0.6 + 1.2) * 3;
  const wingLift = (Math.sin(t * 0.9) * 0.5 + 0.5) * 3;
  const headTilt = Math.sin(t * 0.5 + 2.0) * 2;
  const blinkPhase = t % 4.4;
  const blink = (blinkPhase > 4.1 && blinkPhase < 4.25) ? 0.08 : 1;

  // Fire-breath cycle: the dragon rests, then winds up (jaw opening),
  // breathes a cone of fire that flares and tapers off, then rests again.
  const cyclePeriod = 6.5, breathLen = 1.9, windUp = 0.5;
  const cyclePos = t % cyclePeriod;
  const activeStart = cyclePeriod - breathLen - windUp;
  let jawOpen = 0, fireStrength = 0;
  if (cyclePos > activeStart) {
    const local = cyclePos - activeStart;
    if (local < windUp) {
      jawOpen = local / windUp;
    } else {
      jawOpen = 1;
      const bl = local - windUp;
      const flareIn = Math.min(1, bl / (breathLen * 0.25));
      const flareOut = bl > breathLen * 0.7 ? Math.max(0, (breathLen - bl) / (breathLen * 0.3)) : 1;
      fireStrength = Math.sin(flareIn * Math.PI * 0.5) * flareOut;
    }
  }

  // A soft ground shadow so the dragon reads as standing in the scene.
  ctx.fillStyle = 'rgba(5,2,2,.4)';
  ctx.beginPath();
  ctx.ellipse(cx - 0.12 * s, cy + 0.66 * s, 0.62 * s, 0.09 * s, 0, 0, Math.PI * 2);
  ctx.fill();

  const spriteCanvas = getDragonSpriteCanvas();
  const octx = spriteCanvas.getContext('2d');
  const mouth = renderDragonSprite(octx, { tailWag, wingLift, headTilt, blink, jawOpen });

  // Placement: the sprite's local (96, 88) point is roughly the dragon's
  // ground contact, mapped just in front of the spire's base plinth.
  const pixelScale = s / 92;
  const destW = 168 * pixelScale, destH = 104 * pixelScale;
  const destX = cx - 96 * pixelScale - s * 0.22;
  const destY = cy - 88 * pixelScale + s * 0.635 + breathe;

  ctx.drawImage(spriteCanvas, 0, 0, 168, 104, destX, destY, destW, destH);

  if (fireStrength > 0.02) {
    const mx = destX + mouth.mouthX * pixelScale;
    const my = destY + mouth.mouthY * pixelScale;
    drawDragonFireBreath(mx, my, 0.12, pixelScale, fireStrength, t);
  }

  ctx.restore();
}


function drawBackgroundActivity(era, songTime) {
  const type = era.backgroundType || ''; const groundY = getHitLineY(); const accent = era.palette.accent;
  if (type === 'finale') { drawFinaleScene(era, songTime, GameState.finaleCutscene); return; }
  if (type === 'slums') {
    const count = Math.max(4, Math.ceil(W / 190));
    for (let i=0;i<count;i++) {
      const x=((i*211+songTime*(13+i%3*2))%(W+260))-130, baseY=groundY-2-(i%3)*3, scale=.82+(i%4)*.07;
      const bob=Math.sin(songTime*2.1+i*1.7)*1.2*scale, hx=x+8*scale, hy=baseY-55*scale+bob;
      ctx.save(); ctx.globalAlpha=.68; ctx.fillStyle='#09080b';
      ctx.beginPath(); ctx.moveTo(hx-10*scale,hy+7*scale); ctx.quadraticCurveTo(hx-7*scale,hy-4*scale,hx+2*scale,hy-9*scale); ctx.quadraticCurveTo(hx+16*scale,hy-11*scale,hx+17*scale,hy+7*scale); ctx.lineTo(x+35*scale,hy+30*scale); ctx.quadraticCurveTo(x+39*scale,hy+42*scale,x+28*scale,hy+47*scale); ctx.lineTo(x+19*scale,hy+48*scale); ctx.lineTo(x+25*scale,baseY); ctx.lineTo(x+18*scale,baseY); ctx.lineTo(x+8*scale,hy+48*scale); ctx.lineTo(x+1*scale,baseY); ctx.lineTo(x-5*scale,baseY); ctx.lineTo(x+1*scale,hy+45*scale); ctx.lineTo(x-10*scale,hy+33*scale); ctx.lineTo(x-16*scale,hy+36*scale); ctx.lineTo(x-7*scale,hy+17*scale); ctx.closePath(); ctx.fill();
      // Solid sack, intentionally no strap or internal lines.
      ctx.beginPath(); ctx.moveTo(x+27*scale,hy+14*scale); ctx.quadraticCurveTo(x+42*scale,hy+11*scale,x+47*scale,hy+25*scale); ctx.quadraticCurveTo(x+50*scale,hy+40*scale,x+38*scale,hy+46*scale); ctx.quadraticCurveTo(x+27*scale,hy+46*scale,x+23*scale,hy+36*scale); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
  } else if(type==='market') {
    for(let i=0;i<Math.ceil(W/170)+2;i++){const x=i*170-(bgOffset*.5%170),y=groundY-82;pixelRect(x,y,92,6,accent);pixelRect(x+10,y+6,4,52,era.palette.buildingLight);pixelRect(x+78,y+6,4,52,era.palette.buildingLight);ctx.fillStyle=accent;ctx.beginPath();ctx.moveTo(x-4,y);ctx.lineTo(x+96,y);ctx.lineTo(x+78,y+21);ctx.lineTo(x+10,y+21);ctx.closePath();ctx.fill();}
  } else if(type==='riverside') {
    const waterY=groundY-52; ctx.globalAlpha=.55; for(let r=0;r<8;r++) pixelRect(0,waterY+r*7,W,2,'#6b9b9a'); ctx.globalAlpha=1;
    for(let i=0;i<4;i++){const x=((i*260+songTime*34)%(W+280))-140; const y=waterY-5-(i%2)*10; pixelRect(x,y,74,5,era.palette.building); pixelRect(x+14,y-17,4,17,accent); ctx.fillStyle=accent;ctx.beginPath();ctx.moveTo(x+18,y-17);ctx.lineTo(x+48,y-5);ctx.lineTo(x+18,y-5);ctx.closePath();ctx.fill();}
    for(let i=0;i<5;i++){const x=i*150-(bgOffset%150);pixelRect(x,groundY-112,5,60,era.palette.buildingLight);pixelRect(x+5,groundY-118,30,6,accent);}
  } else if(type==='foundry') {
    for(let i=0;i<4;i++){const x=((i*230-songTime*18)%(W+260))-130;pixelRect(x,groundY-145,74,145,era.palette.building);pixelRect(x+12,groundY-168,50,23,era.palette.buildingLight);pixelRect(x+25,groundY-205,22,37,era.palette.buildingLight);}
    for(let i=0;i<10;i++){const x=((i*87+songTime*8)%(W+40))-20,y=groundY-40-((i*29)%130);pixelRect(x,y,3,3,'#f3a83b');}
  } else if(type==='merchant') {
    for(let i=0;i<Math.ceil(W/210)+1;i++){const x=i*210-(bgOffset%210);pixelRect(x,groundY-118,120,118,era.palette.building);pixelRect(x+8,groundY-128,104,10,accent);pixelRect(x+12,groundY-96,28,24,era.palette.buildingLight);pixelRect(x+72,groundY-96,28,24,era.palette.buildingLight);pixelRect(x+44,groundY-55,30,55,'#3b281b');}
  } else if(type==='harbor') {
    const waterY=groundY-34;ctx.globalAlpha=.55;for(let i=0;i<6;i++)pixelRect(0,waterY+i*6,W,2,accent);for(let i=0;i<4;i++){const x=((i*240+songTime*28)%(W+260))-130,y=waterY-8-(i%2)*12;pixelRect(x,y,58,5,era.palette.building);pixelRect(x+10,y-16,3,16,accent);ctx.beginPath();ctx.moveTo(x+13,y-16);ctx.lineTo(x+38,y-5);ctx.lineTo(x+13,y-5);ctx.closePath();ctx.fillStyle=accent;ctx.fill();}ctx.globalAlpha=1;
  } else if(type==='noble') {
    for(let i=0;i<Math.ceil(W/220)+1;i++){const x=i*220-(bgOffset*.65%220);pixelRect(x,groundY-170,150,170,era.palette.building);pixelRect(x+18,groundY-188,114,18,era.palette.buildingLight);pixelRect(x+18,groundY-145,28,36,accent);pixelRect(x+62,groundY-145,28,36,accent);pixelRect(x+106,groundY-145,28,36,accent);pixelRect(x+54,groundY-62,42,62,'#2b2630');}
  } else if(type==='gardens') {
    for(let i=0;i<Math.ceil(W/130)+2;i++){const x=i*130-(bgOffset*.25%130),y=groundY-75-(i%3)*8;pixelRect(x+18,y+25,7,45,era.palette.buildingLight);ctx.fillStyle=era.palette.building;for(let j=0;j<6;j++){ctx.beginPath();ctx.arc(x+10+(j%3)*12,y+15+Math.floor(j/3)*12,12,0,Math.PI*2);ctx.fill();}const bx=x+65+Math.sin(songTime*1.7+i)*18,by=y-15-(i%2)*18;ctx.fillStyle=era.palette.text;ctx.globalAlpha=.7;pixelRect(bx,by,8,3,era.palette.text);pixelRect(bx+7,by-2,3,2,era.palette.text);ctx.globalAlpha=1;}
  } else if(type==='court') {
    for(let i=0;i<Math.ceil(W/190)+1;i++){const x=i*190-(bgOffset%190),y=groundY-150;pixelRect(x,y,12,110,era.palette.buildingLight);pixelRect(x+12,y+8,40,48,accent);pixelRect(x+16,y+12,32,34,era.palette.building);ctx.globalAlpha=.7;ctx.fillStyle='#ffd66a';ctx.beginPath();ctx.arc(x+6,y-4,6+Math.sin(songTime*4+i)*2,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
  } else if(type==='orbit') {
    for(let i=0;i<4;i++){const x=((i*260-songTime*32)%(W+300))-150,y=groundY-180-(i%2)*35;pixelRect(x,y,150,86,era.palette.building);pixelRect(x+14,y+14,122,6,accent);pixelRect(x+22,y+30,38,28,era.palette.buildingLight);pixelRect(x+72,y+30,54,28,era.palette.buildingLight);}
  } else if(type==='space') {
    for(let i=0;i<5;i++){const x=((i*230+songTime*25)%(W+180))-90,y=H*.16+((i*71)%Math.max(80,H*.32)),sc=.95;ctx.globalAlpha=.7;pixelRect(x,y,42*sc,7*sc,accent);pixelRect(x+10*sc,y-6*sc,22*sc,6*sc,era.palette.buildingLight);pixelRect(x+17*sc,y+7*sc,9*sc,3*sc,era.palette.text);ctx.globalAlpha=1;}
    for(let i=0;i<3;i++){const x=((i*310-songTime*18)%(W+80)+W+80)%(W+80)-40,y=H*.28+i*55;ctx.globalAlpha=.8;ctx.strokeStyle=accent;ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,12,0,Math.PI*2);ctx.stroke();pixelRect(x-7,y+8,14,3,era.palette.text);ctx.globalAlpha=1;}
  }
}

function drawBackground(era, songTime) {
  const p = era.palette;
  
  // Sky gradient (simulated with bands)
  const bands = 20;
  for (let i = 0; i < bands; i++) {
    const t = i / bands;
    const r1 = parseInt(p.skyTop.substr(1, 2), 16);
    const g1 = parseInt(p.skyTop.substr(3, 2), 16);
    const b1 = parseInt(p.skyTop.substr(5, 2), 16);
    const r2 = parseInt(p.skyBot.substr(1, 2), 16);
    const g2 = parseInt(p.skyBot.substr(3, 2), 16);
    const b2 = parseInt(p.skyBot.substr(5, 2), 16);
    const r = Math.floor(r1 + (r2 - r1) * t);
    const g = Math.floor(g1 + (g2 - g1) * t);
    const b = Math.floor(b1 + (b2 - b1) * t);
    pixelRect(0, i * H / bands, W, H / bands + 1, `rgb(${r},${g},${b})`);
  }
  
  // Stars (space era)
  if (p.stars) {
    for (const star of bgStars) {
      star.twinkle += 0.05;
      const b = star.brightness * (0.5 + 0.5 * Math.sin(star.twinkle));
      drawStar(star.x, star.y, b);
      star.x -= star.speed * 0.3;
      if (star.x < 0) star.x = W;
    }
  }
  
  // Animated scenery belongs behind the architecture. Slums are drawn again
  // afterward as a deliberate foreground exception.
  drawBackgroundActivity(era, songTime);

  // Special full-scene backdrops for the two new late-game levels.
  if (era.backgroundType === 'ballroom') {
    // Tall velvet curtains, chandeliers, banners, and a polished dance floor.
    pixelRect(0, H*.10, W*.10, H*.72, p.building); pixelRect(W*.90, H*.10, W*.10, H*.72, p.building);
    for (let i=0;i<5;i++) { const x=W*(.18+i*.16); pixelRect(x,H*.12,4,H*.42,p.accent); pixelRect(x-18,H*.53,36,5,p.accent); ctx.fillStyle=p.accent; ctx.beginPath(); ctx.arc(x,H*.57,10,0,Math.PI*2); ctx.fill(); }
    for(let i=0;i<7;i++){ const x=W*(i/6); pixelRect(x,H*.72,W/6+2,H*.28, i%2 ? '#33203f' : '#25172e'); }
    pixelRect(W*.30,H*.78,W*.40,3,p.accent);
  } else if (era.backgroundType === 'crystal') {
    // Layered cavern walls and glowing crystal formations.
    ctx.fillStyle=p.building; ctx.beginPath(); ctx.moveTo(0,H*.18); ctx.lineTo(W*.12,H*.05); ctx.lineTo(W*.24,H*.22); ctx.lineTo(W*.38,H*.08); ctx.lineTo(W*.52,H*.20); ctx.lineTo(W*.68,H*.06); ctx.lineTo(W*.82,H*.21); ctx.lineTo(W,H*.08); ctx.lineTo(W,H*.55); ctx.lineTo(0,H*.55); ctx.closePath(); ctx.fill();
    for(let i=0;i<14;i++){ const x=(i*83)%Math.max(1,W); const h=35+(i*29)%100; ctx.fillStyle=i%2?p.accent:p.buildingLight; ctx.beginPath(); ctx.moveTo(x,H*.76); ctx.lineTo(x+10,H*.76-h); ctx.lineTo(x+22,H*.76); ctx.closePath(); ctx.fill(); }
    pixelRect(0,H*.76,W,H*.24,p.ground);
  }

  // Distant buildings/silhouettes (parallax + custom editor motion)
  bgOffset += 0.2;
  const buildingSettings = era.buildings || { motion: 'static', amount: 0, offsetX: 0, offsetY: 0, bump: 0, width: 44, height: 80, imageScale: 100, imageMode: 'procedural' };
  const baseW = Math.max(20, Number(buildingSettings.width) || 44);
  const baseH = Math.max(30, Number(buildingSettings.height) || 80);
  const spacing = Math.max(baseW + 12, 60);
  const numBuildings = Math.ceil(W / spacing) + 2;
  const audioBeatPulse = era.custom ? Song.getBeatPulse() : 0;
  let groupX = Number(buildingSettings.offsetX) || 0;
  let groupY = Number(buildingSettings.offsetY) || 0;
  const amount = Number(buildingSettings.amount) || 0;
  // Custom levels use detected audio onsets, not a guessed BPM.
  if (buildingSettings.motion === 'bob') groupY -= audioBeatPulse * amount;
  if (buildingSettings.motion === 'slide') groupX += audioBeatPulse * amount;
  const bump = Math.max(0, Number(buildingSettings.bump) || 0);
  const beatBump = audioBeatPulse * bump;
  // The dragon's throne room is a castle interior, not a skyline — it draws
  // its own architecture (walls, tower) in drawFinaleScene, so the generic
  // building silhouettes are skipped entirely here rather than swapped out.
  if (era.backgroundType !== 'finale') {
    for (let i = 0; i < numBuildings; i++) {
      const bx = (i * spacing - (bgOffset % spacing)) + groupX;
      const variation = 0.78 + ((i * 37) % 31) / 100;
      const bw = baseW * variation;
      const bh = baseH * (0.72 + ((i * 19) % 36) / 100);
      const by = getHitLineY() - bh + groupY - beatBump;
      const pulseScale = 1 + beatBump / 240;
      if (!era.custom) drawThemedBuilding(era, bx, by, bw * pulseScale, bh * pulseScale, i); else drawBuildingVisual(buildingSettings, bx, by, bw * pulseScale, bh * pulseScale, p, i);
    }
  }
  
  // Slums figures are intentionally the one foreground scenery layer, so their
  // silhouettes read as people walking in front of the structures. Other theme
  // activity was already drawn behind the buildings above.
  if ((era.backgroundType || '') === 'slums') drawBackgroundActivity(era, songTime);

  // Neon panels for space era
  if (p.neon) {
    for (let i = 0; i < 5; i++) {
      const nx = (i * 140 - (bgOffset * 1.5) % 140);
      const ny = H * 0.3 + i * 20;
      ctx.fillStyle = p.accent;
      ctx.globalAlpha = 0.15;
      pixelRect(nx, ny, 80, 3, p.accent);
      ctx.globalAlpha = 1;
    }
  }
  
  // Ground
  pixelRect(0, getHitLineY(), W, H, p.ground);
  
  // Ground accent line
  pixelRect(0, getHitLineY(), W, 2, p.accent);
}

// ---------- LANE RENDERING ----------
function getLaneX(lane) {
  const playAreaWidth = Math.min(W * 0.8, 600);
  const startX = (W - playAreaWidth) / 2;
  const laneWidth = playAreaWidth / LANES;
  return startX + lane * laneWidth + laneWidth / 2;
}

function getLaneWidth() {
  const playAreaWidth = Math.min(W * 0.8, 600);
  return playAreaWidth / LANES;
}

function drawLanes(era) {
  const p = era.palette;
  const playAreaWidth = Math.min(W * 0.8, 600);
  const startX = (W - playAreaWidth) / 2;
  const laneW = playAreaWidth / LANES;
  const hitY = getHitLineY();
  
  // Lane backgrounds
  for (let i = 0; i < LANES; i++) {
    const lx = startX + i * laneW;
    // Lane glow when pressed
    if (GameState.hitLaneFlash[i] > 0) {
      ctx.globalAlpha = GameState.hitLaneFlash[i];
      pixelRect(lx, 0, laneW, H, p.laneGlow || 'rgba(255,255,255,0.1)');
      ctx.globalAlpha = 1;
      GameState.hitLaneFlash[i] = Math.max(0, GameState.hitLaneFlash[i] - 0.05);
    }
    
    // Lane divider
    pixelRect(lx, 0, 1, H, 'rgba(255,255,255,0.05)');
  }
  pixelRect(startX + playAreaWidth, 0, 1, H, 'rgba(255,255,255,0.05)');
  
  // Hit line
  pixelRect(startX, hitY - 2, playAreaWidth, 3, p.accent);
  pixelRect(startX, hitY + 1, playAreaWidth, 1, 'rgba(0,0,0,0.5)');
  
  // Hit circles (targets)
  for (let i = 0; i < LANES; i++) {
    const cx = getLaneX(i);
    const radius = Math.min(laneW * 0.35, 24);
    
    // Outer ring
    ctx.strokeStyle = p.accent;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, hitY, radius, 0, Math.PI * 2);
    ctx.stroke();
    
    // Inner fill when active
    if (GameState.hitLaneFlash[i] > 0) {
      ctx.fillStyle = p.noteColors[i];
      ctx.globalAlpha = GameState.hitLaneFlash[i] * 0.5;
      ctx.beginPath();
      ctx.arc(cx, hitY, radius - 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
    
    // Key label inside the circle
    ctx.font = '10px "Press Start 2P", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.fillText(KEY_LABELS[i], cx, hitY);
    ctx.textBaseline = 'alphabetic';
    
    // Key label removed (redundant with touch controls)
  }
}

// ---------- NOTE RENDERING ----------
function drawNotes(era) {
  const p = era.palette;
  const hitY = getHitLineY();
  const playAreaWidth = Math.min(W * 0.8, 600);
  const startX = (W - playAreaWidth) / 2;
  const laneW = playAreaWidth / LANES;
  const noteSize = Math.min(laneW * 0.6, 36);
  
  for (const note of GameState.notes) {
    if (note.hit || note.missed) continue;
    
    const cx = getLaneX(note.lane);
    const cy = note.y;
    if (cy < -noteSize * 2 || cy > H + noteSize * 2) continue;
    
    // Note as 8-bit arrow/diamond
    const color = p.noteColors[note.lane];
    
    // Shadow
    pixelRect(cx - noteSize/2 + 2, cy - noteSize/2 + 2, noteSize, noteSize, 'rgba(0,0,0,0.3)');
    
    // Main body (diamond shape using pixel rects)
    const half = noteSize / 2;
    // Draw diamond
    ctx.fillStyle = color;
    // Top triangle
    ctx.beginPath();
    ctx.moveTo(cx, cy - half);
    ctx.lineTo(cx + half, cy);
    ctx.lineTo(cx, cy + half);
    ctx.lineTo(cx - half, cy);
    ctx.closePath();
    ctx.fill();
    
    // Inner highlight
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    ctx.beginPath();
    ctx.moveTo(cx, cy - half + 4);
    ctx.lineTo(cx + half - 4, cy);
    ctx.lineTo(cx, cy + half - 4);
    ctx.lineTo(cx - half + 4, cy);
    ctx.closePath();
    ctx.fill();
    
    // Outline
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}

// ---------- PARTICLES ----------
function emitParticles(x, y, color, count) {
  for (let i = 0; i < count; i++) {
    GameState.particles.push({
      x: x,
      y: y,
      vx: (Math.random() - 0.5) * 200,
      vy: -Math.random() * 200 - 50,
      life: 0.5 + Math.random() * 0.3,
      maxLife: 0.8,
      color: color,
      size: 3 + Math.random() * 3,
    });
  }
}

function updateParticles(dt) {
  for (let i = GameState.particles.length - 1; i >= 0; i--) {
    const p = GameState.particles[i];
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += 400 * dt;
    p.life -= dt;
    if (p.life <= 0) GameState.particles.splice(i, 1);
  }
}

function drawParticles() {
  for (const p of GameState.particles) {
    const alpha = p.life / p.maxLife;
    ctx.globalAlpha = alpha;
    pixelRect(p.x, p.y, p.size * alpha, p.size * alpha, p.color);
    ctx.globalAlpha = 1;
  }
}

// ---------- GAME LOGIC ----------
function startLevel(levelIndex) {
  const era = ACTIVE_ERAS[Math.min(levelIndex, ACTIVE_ERAS.length - 1)];
  GameState.levelIndex = levelIndex;
  GameState.hp = HP_MAX;
  GameState.combo = 0;
  GameState.maxCombo = 0;
  GameState.perfects = 0;
  GameState.goods = 0;
  GameState.misses = 0;
  GameState.strayMisses = 0;
  GameState.missPenalty = 0;
  GameState.score = 0;
  GameState.particles = [];
  GameState.hitLaneFlash = [0, 0, 0, 0];
  
  // Generate chart (or use the player-made chart for a custom level).
  // Normalize custom note data so older/shared levels still receive numeric
  // timestamps and the gameplay clock can place each note independently.
  if (era.finale) {
    GameState.chart = generateFinaleChart(era);
  } else if (era.custom) {
    const rawNotes = Array.isArray(era.chart?.notes) ? era.chart.notes : [];
    const normalizedNotes = rawNotes.map((n, index) => ({
      lane: Math.max(0, Math.min(LANES - 1, Number(n.lane) || 0)),
      time: Number.isFinite(Number(n.time)) ? Math.max(START_DELAY, Number(n.time)) : START_DELAY + index * 0.5,
      hit: false, missed: false, y: -50, spawned: false
    })).sort((a, b) => a.time - b.time);
    const lastNoteTime = normalizedNotes.length ? normalizedNotes[normalizedNotes.length - 1].time : START_DELAY;
    const storedDuration = Number(era.chart?.duration);
    GameState.chart = {
      notes: normalizedNotes,
      duration: Math.max(START_DELAY, Number.isFinite(storedDuration) ? storedDuration : lastNoteTime + 1)
    };
  } else {
    GameState.chart = generateChart(era, levelIndex);
  }
  GameState.notes = GameState.chart.notes.map(n => ({ ...n }));
  GameState.totalNotes = GameState.notes.length;
  GameState.finaleCutscene = false;
  GameState.finaleCutsceneShown = false;
  
  // Set CSS variables for era palette
  const root = document.documentElement;
  root.style.setProperty('--era-sky-top', era.palette.skyTop);
  root.style.setProperty('--era-sky-bot', era.palette.skyBot);
  root.style.setProperty('--era-ground', era.palette.ground);
  root.style.setProperty('--era-building', era.palette.building);
  root.style.setProperty('--era-accent', era.palette.accent);
  root.style.setProperty('--era-text', era.palette.text);
  root.style.setProperty('--lane-glow', era.palette.laneGlow);
  
  // Update HUD
  document.getElementById('era-name').textContent = era.name;
  document.getElementById('level-display').textContent = `Level ${levelIndex + 1}/${ACTIVE_ERAS.length}`;
  
  // Init stars if needed
  if (era.palette.stars) {
    initStars(80);
  }
  
  // Start music
  AudioEngine.init();
  AudioEngine.resume();
  Song.start(era, GameState.chart);
  
  GameState.phase = 'playing';
  showHUD();
}

function showHUD() {
  document.getElementById('hud').classList.remove('hidden');
  // Touch controls only shown via CSS media query on touch devices
  const touchControls = document.getElementById('touch-controls');
  touchControls.classList.remove('hidden');
  touchControls.classList.add('touch-active');
}

function hideHUD() {
  document.getElementById('hud').classList.add('hidden');
  const touchControls = document.getElementById('touch-controls');
  touchControls.classList.remove('touch-active');
  touchControls.classList.add('hidden');
}

function showJudgement(text, color) {
  const el = document.getElementById('judgement');
  el.textContent = text;
  el.style.color = color;
  el.classList.remove('show');
  void el.offsetWidth; // trigger reflow
  el.classList.add('show');
}

function updateHUD() {
  document.getElementById('score-display').textContent = GameState.score.toLocaleString();
  document.getElementById('combo-display').textContent = GameState.combo;
  const hpFill = document.getElementById('hp-fill');
  hpFill.style.width = (GameState.hp / HP_MAX * 100) + '%';
  if (GameState.hp < 30) {
    hpFill.classList.add('low');
  } else {
    hpFill.classList.remove('low');
  }
}

function hitNote(note, judgement) {
  note.hit = true;
  GameState.hitLaneFlash[note.lane] = 1;
  
  const hitY = getHitLineY();
  const cx = getLaneX(note.lane);
  const era = ACTIVE_ERAS[GameState.levelIndex];
  
  if (judgement === 'perfect') {
    GameState.perfects++;
    GameState.combo++;
    GameState.score += 100 * (1 + Math.floor(GameState.combo / 10) * 0.5);
    GameState.hp = Math.min(HP_MAX, GameState.hp + HP_GAIN_PERFECT);
    showJudgement('PERFECT', '#4faa4a');
    emitParticles(cx, hitY, era.palette.noteColors[note.lane], 12);
    GameState.cameraShake = 3;
  } else if (judgement === 'good') {
    GameState.goods++;
    GameState.combo++;
    GameState.score += 50 * (1 + Math.floor(GameState.combo / 10) * 0.5);
    GameState.hp = Math.min(HP_MAX, GameState.hp + HP_GAIN_GOOD);
    showJudgement('GOOD', '#d4a44a');
    emitParticles(cx, hitY, era.palette.noteColors[note.lane], 6);
  }
  
  if (GameState.combo > GameState.maxCombo) {
    GameState.maxCombo = GameState.combo;
  }
  
  AudioEngine.playHitSFX(note.lane, judgement);
  updateHUD();
}

function missNote(note) {
  if (note) note.missed = true;
  // Each miss costs a little more accuracy than the last one did, so a
  // level with scattered misses stays forgiving but repeated misses get
  // progressively harder to recover from — levels are a bit tougher to
  // clear once you start missing a lot, not just proportionally penalized.
  GameState.missPenalty += 1 + GameState.misses * 0.15;
  GameState.misses++;
  if (!note) GameState.strayMisses++;
  GameState.combo = 0;
  GameState.hp = Math.max(0, GameState.hp - HP_LOSS);
  showJudgement('MISS', '#e44');
  AudioEngine.playMissSFX();
  GameState.cameraShake = 5;
  updateHUD();
  
  if (GameState.hp <= 0) {
    gameOver();
  }
}

function checkInput(lane) {
  if (GameState.finaleCutscene) return;
  const songTime = Song.getSongTime();
  let closestNote = null, closestDiff = Infinity;
  for (const note of GameState.notes) {
    if (note.hit || note.missed || note.lane !== lane) continue;
    const diff = Math.abs(note.time - songTime);
    if (diff < closestDiff) { closestDiff = diff; closestNote = note; }
  }
  if (!closestNote || closestDiff * 1000 > MISS_WINDOW) { missNote(null); return; }
  const diffMs = closestDiff * 1000;
  if (diffMs <= PERFECT_WINDOW) hitNote(closestNote, 'perfect');
  else if (diffMs <= GOOD_WINDOW) hitNote(closestNote, 'good');
  else missNote(null);
}

function levelComplete() {
  GameState.phase = 'levelComplete';
  Song.stop();
  hideHUD();
  
  const era = ACTIVE_ERAS[GameState.levelIndex];
  // Accuracy is weighted rather than a flat hit/attempt ratio: each miss's
  // contribution to the denominator grows with how many misses came
  // before it (see missNote), so strings of misses hurt more than the
  // same number of misses spread out over a clean run.
  const hits = GameState.perfects + GameState.goods;
  const weightedAttempts = hits + GameState.missPenalty;
  const accuracy = weightedAttempts > 0 ? hits / weightedAttempts : 0;
  const passed = accuracy >= PASS_THRESHOLD;
  
  GameState.totalScore += GameState.score;
  GameState.totalPerfects += GameState.perfects;
  GameState.levelsCompleted++;
  
  if (!passed) {
    // Failed - game over
    document.getElementById('game-over-era').textContent = `You failed in ${era.name}`;
    document.getElementById('go-score').textContent = GameState.totalScore.toLocaleString();
    document.getElementById('go-levels').textContent = GameState.levelsCompleted - 1;
    document.getElementById('game-over').classList.add('active');
    GameState.phase = 'gameOver';
    return;
  }
  
  if (GameState.levelIndex >= ACTIVE_ERAS.length - 1) {
    // Victory!
    document.getElementById('v-score').textContent = (GameState.totalScore + GameState.score).toLocaleString();
    document.getElementById('v-perfects').textContent = GameState.totalPerfects;
    document.getElementById('v-combo').textContent = GameState.maxCombo;
    document.getElementById('victory').classList.add('active');
    GameState.phase = 'victory';
    return;
  }
  
  // Show level complete screen
  document.getElementById('complete-title').textContent = `${era.name.toUpperCase()} CLEARED!`;
  document.getElementById('perfect-count').textContent = GameState.perfects;
  document.getElementById('good-count').textContent = GameState.goods;
  document.getElementById('miss-count').textContent = GameState.misses;
  document.getElementById('max-combo-display').textContent = GameState.maxCombo;
  document.getElementById('accuracy-display').textContent = Math.round(accuracy * 100) + '%';
  document.getElementById('final-score').textContent = GameState.score.toLocaleString();
  document.getElementById('level-complete').classList.add('active');
}

function gameOver() {
  Song.stop();
  hideHUD();
  const era = ACTIVE_ERAS[GameState.levelIndex];
  document.getElementById('game-over-era').textContent = `You fell in ${era.name}`;
  document.getElementById('go-score').textContent = GameState.totalScore.toLocaleString();
  document.getElementById('go-levels').textContent = GameState.levelsCompleted;
  document.getElementById('game-over').classList.add('active');
  GameState.phase = 'gameOver';
}

function resetGame() {
  GameState.totalScore = 0;
  GameState.totalPerfects = 0;
  GameState.levelsCompleted = 0;
  GameState.score = 0;
  GameState.combo = 0;
  GameState.maxCombo = 0;
  GameState.hp = HP_MAX;
  GameState.particles = [];
  GameState.notes = [];
  GameState.finaleCutscene = false;
  GameState.finaleCutsceneShown = false;
}

// ---------- UPDATE LOOP ----------
let lastTime = 0;
let frameCount = 0;
let fpsTime = 0;
let fps = 60;

function update(dt) {
  if (GameState.phase !== 'playing') return;
  
  // Update music sequencer
  Song.update();
  
  // Get song time from audio context
  const songTime = Song.getSongTime();
  const era = ACTIVE_ERAS[GameState.levelIndex];

  // The finale pauses the gameplay layer during the dragon reveal. Music is
  // deliberately silent in this interval because the finale chart has a
  // matching gap; notes keep their positions until the charge resumes.
  if (era.finale) {
    const cutStart = era.cutsceneAt;
    const cutEnd = cutStart + era.cutsceneDuration;
    const inCutscene = songTime >= cutStart && songTime < cutEnd;
    if (inCutscene) {
      GameState.finaleCutscene = true;
      GameState.finaleCutsceneShown = true;
      updateParticles(dt);
      return;
    }
    GameState.finaleCutscene = false;
  }
  
  // Update note positions
  const hitY = getHitLineY();
  const spawnTime = NOTE_SPAWN_AHEAD;
  
  for (const note of GameState.notes) {
    if (note.hit || note.missed) continue;
    
    // Calculate visual y position based on time until hit
    const timeUntilHit = note.time - songTime;
    
    // Always derive the visual position from the note's absolute song time.
    // This is especially important for custom charts: leaving note.y at its
    // initial value can make several recorded notes appear stacked at the hit circle.
    const finaleSpeed = era.finale && era.cutsceneAt && songTime >= era.cutsceneAt + era.cutsceneDuration ? 1.18 : 1;
    note.y = hitY - (timeUntilHit / (spawnTime / finaleSpeed)) * (hitY + 50);
    note.spawned = timeUntilHit < spawnTime / finaleSpeed;
    
    // Check for missed notes (past the hit window)
    if (timeUntilHit < -MISS_WINDOW / 1000 && !note.hit) {
      missNote(note);
    }
  }
  
  // Check if level is complete (all notes resolved and song ended)
  const allResolved = GameState.notes.every(n => n.hit || n.missed);
  if (allResolved || songTime > GameState.chart.duration + 1) {
    levelComplete();
    return;
  }
  
  // Update particles
  updateParticles(dt);
  
  // Camera shake decay
  if (GameState.cameraShake > 0) {
    GameState.cameraShake = Math.max(0, GameState.cameraShake - dt * 30);
  }
}

function render() {
  ctx.clearRect(0, 0, W, H);
  
  if (GameState.phase === 'playing' || GameState.phase === 'levelComplete') {
    const era = ACTIVE_ERAS[GameState.levelIndex];
    
    // Camera shake
    ctx.save();
    if (GameState.cameraShake > 0) {
      ctx.translate(
        (Math.random() - 0.5) * GameState.cameraShake,
        (Math.random() - 0.5) * GameState.cameraShake
      );
    }
    
    drawBackground(era, Song.getSongTime());
    if (!GameState.finaleCutscene) {
      drawLanes(era);
      drawNotes(era);
    }
    drawParticles();
    
    ctx.restore();
  } else if (GameState.phase === 'title') {
    // Title screen background
    const era = ERAS[0];
    drawBackground(era, 0);
  } else {
    // Show current era background on overlays
    const era = ACTIVE_ERAS[Math.min(GameState.levelIndex, ACTIVE_ERAS.length - 1)];
    drawBackground(era, 0);
  }
}

function gameLoop(timestamp) {
  const dt = Math.min((timestamp - lastTime) / 1000, 0.1);
  lastTime = timestamp;
  
  // FPS tracking
  frameCount++;
  fpsTime += dt;
  if (fpsTime >= 0.5) {
    fps = Math.round(frameCount / fpsTime);
    frameCount = 0;
    fpsTime = 0;
    const dbg = document.getElementById('debug');
    if (!dbg.classList.contains('hidden')) {
      dbg.textContent = `FPS: ${fps} | Notes: ${GameState.notes.filter(n => !n.hit && !n.missed).length} | HP: ${Math.round(GameState.hp)} | Phase: ${GameState.phase}`;
    }
  }
  
  update(dt);
  render();
  if (editorRecording) updateEditorRecordingUI();
  
  requestAnimationFrame(gameLoop);
}

// ---------- INPUT ----------
const Input = {
  keys: {},
  justPressed: {},
  
  init() {
    document.addEventListener('keydown', (e) => {
      if (!this.keys[e.code]) this.justPressed[e.code] = true;
      this.keys[e.code] = true;
      
      if (editorRecording) {
        const laneIdx = KEYS.indexOf(e.code);
        if (laneIdx >= 0) {
          e.preventDefault();
          recordEditorTap(laneIdx);
        }
        return;
      }

      if (GameState.phase === 'playing') {
        const laneIdx = KEYS.indexOf(e.code);
        if (laneIdx >= 0) {
          e.preventDefault();
          checkInput(laneIdx);
        }
      }
    });
    
    document.addEventListener('keyup', (e) => {
      this.keys[e.code] = false;
    });
    
    // The visual hit circles on the game canvas are also tappable on mobile.
    // Keep the original bottom lane buttons as a second input method.
    const gameCanvas = document.getElementById('gameCanvas');
    if (gameCanvas) {
      gameCanvas.style.touchAction = 'none';
      gameCanvas.addEventListener('pointerdown', (e) => {
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        if (GameState.phase !== 'playing') return;

        const rect = gameCanvas.getBoundingClientRect();
        if (!rect.width || !rect.height) return;
        const x = (e.clientX - rect.left) * (W / rect.width);
        const y = (e.clientY - rect.top) * (H / rect.height);
        const playAreaWidth = Math.min(W * 0.8, 600);
        const startX = (W - playAreaWidth) / 2;
        const laneW = playAreaWidth / LANES;
        const hitY = getHitLineY();
        const radius = Math.min(laneW * 0.35, 24);
        const hitRadius = Math.max(radius * 1.35, 28);

        if (x < startX || x > startX + playAreaWidth) return;
        const lane = Math.max(0, Math.min(LANES - 1, Math.floor((x - startX) / laneW)));
        const cx = getLaneX(lane);
        const distance = Math.hypot(x - cx, y - hitY);
        if (distance <= hitRadius) {
          e.preventDefault();
          try { gameCanvas.setPointerCapture(e.pointerId); } catch (_) {}
          checkInput(lane);
          GameState.hitLaneFlash[lane] = 1;
        }
      }, { passive: false });
    }

    // Mobile touch controls. Pointer events work reliably in Android WebView
    // and avoid the touchstart/mousedown double-fire that can happen on phones.
    const touchLanes = document.querySelectorAll('.touch-lane');
    touchLanes.forEach((el, i) => {
      el.style.touchAction = 'none';
      el.addEventListener('pointerdown', (e) => {
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        e.preventDefault();
        try { el.setPointerCapture(e.pointerId); } catch (_) {}
        if (GameState.phase === 'playing') {
          checkInput(i);
          el.classList.add('active');
          window.setTimeout(() => el.classList.remove('active'), 110);
        }
      }, { passive: false });
      el.addEventListener('click', (e) => {
        // Fallback for Android WebView builds where pointer events are disabled.
        if (GameState.phase === 'playing' && !('PointerEvent' in window)) {
          e.preventDefault(); checkInput(i);
        }
      });
      el.addEventListener('pointerup', (e) => { e.preventDefault(); el.classList.remove('active'); }, { passive: false });
      el.addEventListener('pointercancel', () => el.classList.remove('active'));
    });
  },
  
  endFrame() {
    this.justPressed = {};
  },
};

// ---------- SETTINGS / KEYBINDS ----------
let rebindingLane = null;
let phaseBeforeSettings = null;
const LANE_NAMES = ['Lane 1', 'Lane 2', 'Lane 3', 'Lane 4'];

function currentPaletteColors() {
  const era = ACTIVE_ERAS[Math.min(GameState.levelIndex, ACTIVE_ERAS.length - 1)];
  return era.palette.noteColors;
}

function refreshKeyLabels() {
  KEY_LABELS = KEYS.map(codeToLabel);

  const hint = document.getElementById('controls-keys-hint');
  if (hint) hint.textContent = 'Keys: ' + KEY_LABELS.join(' \u00A0 ');

  for (let i = 0; i < LANES; i++) {
    const span = document.getElementById('touch-label-' + i);
    if (span) span.textContent = KEY_LABELS[i];
  }

  renderKeybindRows();
}

function renderKeybindRows() {
  const list = document.getElementById('keybind-list');
  if (!list) return;
  const colors = currentPaletteColors();
  list.innerHTML = '';

  for (let i = 0; i < LANES; i++) {
    const row = document.createElement('div');
    row.className = 'keybind-row';

    const laneInfo = document.createElement('div');
    laneInfo.className = 'keybind-lane';
    const swatch = document.createElement('span');
    swatch.className = 'keybind-swatch';
    swatch.style.background = colors[i] || '#888';
    laneInfo.appendChild(swatch);
    laneInfo.appendChild(document.createTextNode(LANE_NAMES[i]));

    const keyDisplay = document.createElement('span');
    keyDisplay.className = 'keybind-key';
    keyDisplay.id = 'keybind-key-' + i;
    keyDisplay.textContent = KEY_LABELS[i];

    const rebindBtn = document.createElement('button');
    rebindBtn.className = 'keybind-rebind-btn';
    rebindBtn.id = 'keybind-rebind-' + i;
    rebindBtn.textContent = 'REBIND';
    rebindBtn.addEventListener('click', () => startRebind(i));

    row.appendChild(laneInfo);
    row.appendChild(keyDisplay);
    row.appendChild(rebindBtn);
    list.appendChild(row);
  }
}

function startRebind(lane) {
  // Cancel any other lane currently listening
  if (rebindingLane !== null) {
    const prevBtn = document.getElementById('keybind-rebind-' + rebindingLane);
    if (prevBtn) { prevBtn.textContent = 'REBIND'; prevBtn.classList.remove('listening'); }
  }
  rebindingLane = lane;
  const btn = document.getElementById('keybind-rebind-' + lane);
  if (btn) {
    btn.textContent = 'PRESS A KEY…';
    btn.classList.add('listening');
    btn.classList.remove('warn');
  }
}

function cancelRebind() {
  if (rebindingLane === null) return;
  const btn = document.getElementById('keybind-rebind-' + rebindingLane);
  if (btn) { btn.textContent = 'REBIND'; btn.classList.remove('listening'); }
  rebindingLane = null;
}

function assignKeybind(lane, code) {
  const dupeIndex = KEYS.findIndex((k, idx) => k === code && idx !== lane);
  if (dupeIndex !== -1) {
    const btn = document.getElementById('keybind-rebind-' + lane);
    if (btn) {
      btn.textContent = 'ALREADY USED';
      btn.classList.add('warn');
      setTimeout(() => {
        if (rebindingLane === lane) {
          btn.textContent = 'PRESS A KEY…';
          btn.classList.remove('warn');
        }
      }, 900);
    }
    return; // keep listening so the player can try another key
  }

  KEYS[lane] = code;
  saveKeybinds();
  rebindingLane = null;

  const btn = document.getElementById('keybind-rebind-' + lane);
  if (btn) { btn.textContent = 'REBIND'; btn.classList.remove('listening'); }
  const keyDisplay = document.getElementById('keybind-key-' + lane);
  if (keyDisplay) keyDisplay.textContent = codeToLabel(code);

  refreshKeyLabels();
}

// Capture phase: intercepts the very next keydown while a rebind is in
// progress, before it reaches the gameplay input handler or debug toggle.
document.addEventListener('keydown', (e) => {
  if (rebindingLane === null) return;
  e.preventDefault();
  e.stopPropagation();
  if (e.code === 'Escape') {
    cancelRebind();
    return;
  }
  assignKeybind(rebindingLane, e.code);
}, true);

function openSettings() {
  if (GameState.phase === 'playing') {
    phaseBeforeSettings = 'playing';
    GameState.phase = 'paused';
    Song.pause();
  } else {
    phaseBeforeSettings = null;
  }
  refreshKeyLabels();
  document.getElementById('settings-modal').classList.add('active');
}

function closeSettings() {
  cancelRebind();
  document.getElementById('settings-modal').classList.remove('active');
  if (phaseBeforeSettings === 'playing') {
    Song.resume();
    GameState.phase = 'playing';
  }
  phaseBeforeSettings = null;
}

document.getElementById('settings-btn').addEventListener('click', openSettings);
document.getElementById('close-settings-btn').addEventListener('click', closeSettings);

function refreshVolumeLabels() {
  const music = document.getElementById('music-volume');
  const sfx = document.getElementById('sfx-volume');
  if (music) music.value = String(AudioSettings.music);
  if (sfx) sfx.value = String(AudioSettings.sfx);
  const musicLabel = document.getElementById('music-volume-value');
  const sfxLabel = document.getElementById('sfx-volume-value');
  if (musicLabel) musicLabel.textContent = `${AudioSettings.music}%`;
  if (sfxLabel) sfxLabel.textContent = `${AudioSettings.sfx}%`;
}

document.getElementById('music-volume')?.addEventListener('input', (e) => {
  AudioSettings.music = Math.max(0, Math.min(150, Number(e.target.value)));
  refreshVolumeLabels();
  saveAudioSettings();
});
document.getElementById('sfx-volume')?.addEventListener('input', (e) => {
  AudioSettings.sfx = Math.max(0, Math.min(150, Number(e.target.value)));
  refreshVolumeLabels();
  saveAudioSettings();
});
refreshVolumeLabels();
document.getElementById('reset-keybinds-btn').addEventListener('click', () => {
  cancelRebind();
  KEYS = DEFAULT_KEYS.slice();
  saveKeybinds();
  refreshKeyLabels();
});

refreshKeyLabels();

// ---------- LEVEL EDITOR ----------
let editorRecording = false;
const EditorState = {
  audioFile: null,
  audioObjectUrl: null,
  audioUrl: '',
  duration: 0,
  notes: [],
  buildingImageData: null,
  phaseBeforeEditor: null,
  recordingStartedAt: 0,
  recordingAudioOffset: 0,
  recordingClockActive: false,
};

function shadeColor(hex, percent) {
  const num = parseInt(hex.slice(1), 16);
  let r = (num >> 16) + Math.round(255 * percent);
  let g = ((num >> 8) & 0xff) + Math.round(255 * percent);
  let b = (num & 0xff) + Math.round(255 * percent);
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  return '#' + (0x1000000 + r * 0x10000 + g * 0x100 + b).toString(16).slice(1);
}

function hexToRgba(hex, alpha) {
  const num = parseInt(hex.slice(1), 16);
  const r = (num >> 16) & 0xff, g = (num >> 8) & 0xff, b = num & 0xff;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function readEditorColors() {
  return {
    skyTop: document.getElementById('editor-color-skyTop').value,
    skyBot: document.getElementById('editor-color-skyBot').value,
    building: document.getElementById('editor-color-building').value,
    accent: document.getElementById('editor-color-accent').value,
    notes: [0, 1, 2, 3].map(i => document.getElementById('editor-color-note' + i).value),
    stars: document.getElementById('editor-toggle-stars').checked,
    neon: document.getElementById('editor-toggle-neon').checked,
  };
}

function buildPaletteFromEditor() {
  const c = readEditorColors();
  return {
    skyTop: c.skyTop,
    skyBot: c.skyBot,
    ground: shadeColor(c.skyBot, -0.15),
    building: c.building,
    buildingLight: shadeColor(c.building, 0.15),
    accent: c.accent,
    text: shadeColor(c.accent, 0.4),
    noteColors: c.notes,
    laneGlow: hexToRgba(c.accent, 0.18),
    stars: c.stars,
    neon: c.neon,
  };
}

function readEditorBuildings() {
  const motion = document.getElementById('editor-building-motion')?.value || 'static';
  const amount = Number(document.getElementById('editor-building-motion-amount')?.value || 0);
  const offsetX = Number(document.getElementById('editor-building-offset-x')?.value || 0);
  const offsetY = Number(document.getElementById('editor-building-offset-y')?.value || 0);
  const bump = Number(document.getElementById('editor-building-bump')?.value || 0);
  const width = Number(document.getElementById('editor-building-width')?.value || 44);
  const height = Number(document.getElementById('editor-building-height')?.value || 80);
  const imageScale = Number(document.getElementById('editor-building-scale')?.value || 100);
  const imageMode = document.getElementById('editor-building-image')?.value || 'procedural';
  return { motion, amount, offsetX, offsetY, bump, width, height, imageScale, imageMode, imageData: EditorState.buildingImageData || null };
}

function updateBuildingEditorLabels() {
  const ids = [
    ['editor-building-motion-amount', 'editor-building-motion-amount-value'],
    ['editor-building-offset-x', 'editor-building-offset-x-value'],
    ['editor-building-offset-y', 'editor-building-offset-y-value'],
    ['editor-building-bump', 'editor-building-bump-value'],
    ['editor-building-width', 'editor-building-width-value'],
    ['editor-building-height', 'editor-building-height-value'],
    ['editor-building-scale', 'editor-building-scale-value'],
  ];
  ids.forEach(([inputId, labelId]) => {
    const input = document.getElementById(inputId);
    const label = document.getElementById(labelId);
    if (input && label) label.textContent = input.value;
  });
}

function drawEditorPreview() {
  const canvas = document.getElementById('editor-preview-canvas');
  if (!canvas) return;
  const pctx = canvas.getContext('2d');
  const pw = canvas.width, ph = canvas.height;
  const p = buildPaletteFromEditor();

  const bands = 12;
  for (let i = 0; i < bands; i++) {
    const t = i / bands;
    const r1 = parseInt(p.skyTop.substr(1, 2), 16), g1 = parseInt(p.skyTop.substr(3, 2), 16), b1 = parseInt(p.skyTop.substr(5, 2), 16);
    const r2 = parseInt(p.skyBot.substr(1, 2), 16), g2 = parseInt(p.skyBot.substr(3, 2), 16), b2 = parseInt(p.skyBot.substr(5, 2), 16);
    const r = Math.floor(r1 + (r2 - r1) * t), g = Math.floor(g1 + (g2 - g1) * t), b = Math.floor(b1 + (b2 - b1) * t);
    pctx.fillStyle = `rgb(${r},${g},${b})`;
    pctx.fillRect(0, i * ph / bands, pw, ph / bands + 1);
  }

  if (p.stars) {
    pctx.fillStyle = 'rgba(255,255,255,0.8)';
    for (let i = 0; i < 20; i++) {
      const sx = (i * 37) % pw;
      const sy = (i * 53) % (ph * 0.6);
      pctx.fillRect(sx, sy, 1, 1);
    }
  }

  pctx.fillStyle = p.building;
  pctx.fillRect(0, ph * 0.6, pw, ph * 0.4);
  pctx.fillStyle = p.accent;
  pctx.fillRect(0, ph * 0.6 - 2, pw, 2);

  const swatchW = pw / 4;
  for (let i = 0; i < 4; i++) {
    pctx.fillStyle = p.noteColors[i] || '#888';
    pctx.fillRect(i * swatchW + swatchW / 2 - 6, ph * 0.6 - 20, 12, 12);
  }
}

['skyTop', 'skyBot', 'building', 'accent', 'note0', 'note1', 'note2', 'note3'].forEach(id => {
  const el = document.getElementById('editor-color-' + id);
  if (el) el.addEventListener('input', drawEditorPreview);
});
document.getElementById('editor-toggle-stars').addEventListener('change', drawEditorPreview);
document.getElementById('editor-toggle-neon').addEventListener('change', drawEditorPreview);
['editor-building-image', 'editor-building-motion', 'editor-building-motion-amount', 'editor-building-offset-x', 'editor-building-offset-y', 'editor-building-bump', 'editor-building-width', 'editor-building-height', 'editor-building-scale'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('input', () => { updateBuildingEditorLabels(); drawEditorPreview(); });
});
updateBuildingEditorLabels();

document.getElementById('editor-building-image-file')?.addEventListener('change', (e) => {
  const file = e.target.files[0];
  const ytWrap = document.getElementById('editor-youtube-player-wrap');
  if (ytWrap) ytWrap.classList.add('hidden');
  YouTubePlayer.stop();
  const status = document.getElementById('editor-building-image-status');
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 512;
      const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(img.naturalWidth * scale));
      c.height = Math.max(1, Math.round(img.naturalHeight * scale));
      const cctx = c.getContext('2d');
      cctx.drawImage(img, 0, 0, c.width, c.height);
      EditorState.buildingImageData = c.toDataURL('image/webp', 0.82);
      document.getElementById('editor-building-image').value = 'custom';
      if (status) status.textContent = `Loaded: ${file.name}`;
      drawEditorPreview();
    };
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
});

function formatTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return m + ':' + String(s).padStart(2, '0');
}


function makeDemoBeatBlob() {
  const sampleRate = 44100, bpm = 110, duration = 36, samples = Math.floor(sampleRate * duration);
  const data = new Float32Array(samples);
  const beatSamples = Math.floor(sampleRate * 60 / bpm);
  for (let i = 0; i < samples; i++) {
    const beatPos = i % beatSamples;
    const beat = Math.floor(i / beatSamples);
    let v = 0;
    if (beatPos < sampleRate * 0.045) { const t=beatPos/sampleRate; v += Math.sin(2*Math.PI*(beat%4===0?110:220)*t)*Math.exp(-t*55)*0.45; }
    if (beatPos < sampleRate * 0.018) { const t=beatPos/sampleRate; v += (Math.random()*2-1)*Math.exp(-t*180)*0.12; }
    data[i]=Math.max(-1,Math.min(1,v));
  }
  const buffer = new ArrayBuffer(44 + data.length*2), view = new DataView(buffer);
  const write=(o,str)=>[...str].forEach((c,j)=>view.setUint8(o+j,c.charCodeAt(0)));
  write(0,'RIFF'); view.setUint32(4,36+data.length*2,true); write(8,'WAVE'); write(12,'fmt '); view.setUint32(16,16,true); view.setUint16(20,1,true); view.setUint16(22,1,true); view.setUint32(24,sampleRate,true); view.setUint32(28,sampleRate*2,true); view.setUint16(32,2,true); view.setUint16(34,16,true); write(36,'data'); view.setUint32(40,data.length*2,true);
  for(let i=0;i<data.length;i++) view.setInt16(44+i*2, data[i]*32767, true);
  return new Blob([buffer],{type:'audio/wav'});
}
function useDemoBeat() {
  const ytWrap = document.getElementById('editor-youtube-player-wrap');
  if (ytWrap) ytWrap.classList.add('hidden');
  YouTubePlayer.stop();
  if (EditorState.audioObjectUrl) URL.revokeObjectURL(EditorState.audioObjectUrl);
  const blob=makeDemoBeatBlob();
  EditorState.audioFile=blob; EditorState.audioUrl=''; EditorState.audioObjectUrl=URL.createObjectURL(blob); EditorState.duration=36; const urlInput=document.getElementById('editor-audio-url'); if(urlInput) urlInput.value='';
  const preview=document.getElementById('editor-audio-preview'), status=document.getElementById('editor-audio-status');
  preview.src=EditorState.audioObjectUrl; preview.classList.remove('hidden'); status.textContent='Built-in demo beat (36 seconds)';
}
document.getElementById('editor-demo-audio-btn')?.addEventListener('click', useDemoBeat);

document.getElementById('editor-audio-file').addEventListener('change', (e) => {
  const file = e.target.files[0];
  const status = document.getElementById('editor-audio-status');
  const preview = document.getElementById('editor-audio-preview');
  if (!file) return;

  if (EditorState.audioObjectUrl) URL.revokeObjectURL(EditorState.audioObjectUrl);
  EditorState.audioFile = file;
  EditorState.audioUrl = '';
  const urlInput = document.getElementById('editor-audio-url');
  if (urlInput) urlInput.value = '';
  EditorState.audioObjectUrl = URL.createObjectURL(file);
  preview.src = EditorState.audioObjectUrl;
  preview.classList.remove('hidden');
  status.textContent = 'Loading…';

  preview.addEventListener('loadedmetadata', function onMeta() {
    EditorState.duration = preview.duration;
    status.textContent = `Loaded: ${file.name} (${formatTime(preview.duration)})`;
    preview.removeEventListener('loadedmetadata', onMeta);
  });
});

// ---------- YOUTUBE PLAYER SUPPORT ----------
// YouTube links are played through the official embedded player. We never
// extract or download YouTube audio; the player remains responsible for playback.
let youtubeApiPromise = null;
function loadYouTubeApi() {
  if (window.YT && window.YT.Player) return Promise.resolve();
  if (youtubeApiPromise) return youtubeApiPromise;
  youtubeApiPromise = new Promise((resolve, reject) => {
    const previous = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      if (typeof previous === 'function') previous();
      resolve();
    };
    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    script.async = true;
    script.onerror = () => reject(new Error('Could not load the YouTube player. Check your internet connection.'));
    document.head.appendChild(script);
  });
  return youtubeApiPromise;
}

function getYouTubeVideoId(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\\./, '').toLowerCase();
    if (host === 'youtu.be') return u.pathname.slice(1).split('/')[0] || null;
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'music.youtube.com') {
      if (u.pathname === '/watch') return u.searchParams.get('v');
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'live') return parts[1] || null;
    }
  } catch (_) {}
  return null;
}

const YouTubePlayer = {
  player: null,
  videoId: null,
  ready: false,
  playing: false,
  ended: false,
  duration: 0,
  pendingPlay: false,
  onEnded: null,
  loadPromise: null,
  async load(url, containerId='editor-youtube-player') {
    const id = getYouTubeVideoId(url);
    if (!id) throw new Error('That is not a valid YouTube video link.');
    await loadYouTubeApi();

    if (this.player && this.videoId === id && this.ready) {
      return this.duration || this.player.getDuration() || 0;
    }

    const container = document.getElementById(containerId);
    if (!container) throw new Error('YouTube player container is unavailable.');

    this.videoId = id;
    this.ready = false;
    this.ended = false;
    this.playing = false;
    this.pendingPlay = false;
    this.duration = 0;

    if (this.player && this.player.destroy) {
      try { this.player.destroy(); } catch (_) {}
      this.player = null;
    }

    this.loadPromise = new Promise((resolve, reject) => {
      let settled = false;
      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        fn(value);
      };
      this.player = new YT.Player(containerId, {
        videoId: id,
        playerVars: {
          playsinline: 1,
          controls: 1,
          rel: 0,
          modestbranding: 1,
          enablejsapi: 1,
          ...(location.protocol === 'http:' || location.protocol === 'https:' ? { origin: location.origin } : {})
        },
        events: {
          onReady: (e) => {
            this.ready = true;
            this.duration = e.target.getDuration() || 0;
            finish(resolve, this.duration);
            if (this.pendingPlay) {
              this.pendingPlay = false;
              try { e.target.playVideo(); } catch (_) {}
            }
          },
          onStateChange: (e) => {
            this.playing = e.data === YT.PlayerState.PLAYING;
            this.ended = e.data === YT.PlayerState.ENDED;
            if (this.playing) this.duration = this.player.getDuration() || this.duration;
            if (this.ended && typeof this.onEnded === 'function') this.onEnded();
          },
          onError: (e) => {
            const code = e?.data;
            finish(reject, new Error(`YouTube could not play this video (error ${code}).`));
          }
        }
      });
    });
    return this.loadPromise;
  },
  play() {
    if (this.ready && this.player) {
      try { this.player.playVideo(); } catch (_) {}
    } else {
      this.pendingPlay = true;
    }
  },
  pause() { if (this.ready && this.player) { try { this.player.pauseVideo(); } catch (_) {} } },
  stop() {
    if (this.player) { try { this.player.stopVideo(); } catch (_) {} }
    this.playing = false;
    this.ended = false;
    this.pendingPlay = false;
    this.onEnded = null;
  },
  getCurrentTime() {
    try { return this.ready && this.player ? (this.player.getCurrentTime() || 0) : 0; } catch (_) { return 0; }
  },
  getDuration() {
    try { return this.ready && this.player ? (this.player.getDuration() || this.duration || 0) : this.duration || 0; } catch (_) { return this.duration || 0; }
  }
};

// Mobile-friendly music URL handler. Supports direct audio URLs and YouTube links.
document.getElementById('editor-audio-url')?.addEventListener('change', async (e) => {
  const url=e.target.value.trim();
  const status=document.getElementById('editor-audio-status');
  const preview=document.getElementById('editor-audio-preview');
  const ytWrap=document.getElementById('editor-youtube-player-wrap');
  if(!url)return;
  if(!/^https:\/\//i.test(url)){status.textContent='Please use an HTTPS URL.';return;}
  const ytId=getYouTubeVideoId(url);
  if (ytId) {
    if (EditorState.audioObjectUrl?.startsWith('blob:')) URL.revokeObjectURL(EditorState.audioObjectUrl);
    EditorState.audioFile=null; EditorState.audioUrl=url; EditorState.audioObjectUrl=url;
    if (document.getElementById('editor-audio-file')) document.getElementById('editor-audio-file').value='';
    preview.pause(); preview.removeAttribute('src'); preview.classList.add('hidden');
    ytWrap?.classList.remove('hidden');
    status.textContent='Loading YouTube player…';
    try {
      await YouTubePlayer.load(url);
      EditorState.duration=YouTubePlayer.getDuration();
      status.textContent=EditorState.duration ? `YouTube song loaded (${formatTime(EditorState.duration)}). Press START RECORDING to play.` : 'YouTube song loaded. Press START RECORDING to play.';
    } catch (err) {
      status.textContent=err.message || 'Could not load the YouTube video.';
    }
    return;
  }
  if (ytWrap) ytWrap.classList.add('hidden');
  if (EditorState.audioObjectUrl?.startsWith('blob:')) URL.revokeObjectURL(EditorState.audioObjectUrl);
  EditorState.audioFile=null; EditorState.audioUrl=url; EditorState.audioObjectUrl=url;
  const fileInput=document.getElementById('editor-audio-file'); if(fileInput) fileInput.value='';
  preview.src=url; preview.classList.remove('hidden'); status.textContent='Loading music URL…';
  const onMeta=()=>{EditorState.duration=Number.isFinite(preview.duration)?preview.duration:0;status.textContent=`Music URL loaded (${formatTime(EditorState.duration)})`;preview.removeEventListener('loadedmetadata',onMeta);};
  const onErr=()=>{status.textContent='Could not load that URL. Use a direct HTTPS MP3/WAV/OGG URL or a YouTube link.';preview.removeEventListener('error',onErr);};
  preview.addEventListener('loadedmetadata',onMeta); preview.addEventListener('error',onErr);
});

function openEditor() {
  EditorState.phaseBeforeEditor = GameState.phase;
  EditorState.audioFile = null;
  EditorState.audioUrl = '';
  EditorState.duration = 0;
  document.getElementById('editor-youtube-player-wrap')?.classList.add('hidden');
  YouTubePlayer.stop();
  GameState.phase = 'editor';
  document.getElementById('title-screen').classList.remove('active');
  document.getElementById('editor-screen').classList.add('active');
  goToEditorStep(1);
  drawEditorPreview();
}

function closeEditor() {
  stopEditorRecordingIfActive();
  document.getElementById('editor-screen').classList.remove('active');
  document.getElementById('title-screen').classList.add('active');
  GameState.phase = 'title';
}

function goToEditorStep(step) {
  document.getElementById('editor-step-1').classList.toggle('hidden', step !== 1);
  document.getElementById('editor-step-2').classList.toggle('hidden', step !== 2);
  if (step === 2) {
    document.getElementById('editor-record-keys').textContent = KEY_LABELS.join(' ');
    for (let i = 0; i < LANES; i++) {
      const lbl = document.getElementById('editor-tap-label-' + i);
      if (lbl) lbl.textContent = KEY_LABELS[i];
    }
    resetRecordingUI();
  }
}

document.getElementById('create-level-btn').addEventListener('click', openEditor);
document.getElementById('editor-cancel-btn').addEventListener('click', closeEditor);
document.getElementById('editor-back-btn').addEventListener('click', () => {
  stopEditorRecordingIfActive();
  goToEditorStep(1);
});

document.getElementById('editor-next-btn').addEventListener('click', () => {
  const name = document.getElementById('editor-name').value.trim();
  if (!EditorState.audioFile && !EditorState.audioUrl) {
    alert('Choose a music file, use the demo beat, or paste an HTTPS MP3/WAV/OGG URL or YouTube link first.');
    return;
  }
  if (!name) {
    alert('Please give your level a name.');
    return;
  }
  goToEditorStep(2);
});

function resetRecordingUI() {
  EditorState.notes = [];
  EditorState.recordingStartedAt = 0;
  EditorState.recordingClockActive = false;
  document.getElementById('editor-record-btn').classList.remove('hidden');
  document.getElementById('editor-record-btn').textContent = 'START RECORDING';
  document.getElementById('editor-rerecord-btn').classList.add('hidden');
  document.getElementById('editor-save-btn').classList.add('hidden');
  document.getElementById('editor-record-time').textContent = '0:00 / ' + formatTime(EditorState.duration);
  document.getElementById('editor-record-count').textContent = '0';
}


async function startEditorRecording() {
  EditorState.notes = [];
  editorRecording = true;
  EditorState.recordingStartedAt = performance.now();
  EditorState.recordingAudioOffset = 0;
  EditorState.recordingClockActive = true;

  const btn = document.getElementById('editor-record-btn');
  btn.textContent = 'STOP RECORDING';

  const ytId = getYouTubeVideoId(EditorState.audioUrl || '');
  if (ytId) {
    YouTubePlayer.onEnded = onEditorRecordingEnded;
    try {
      if (!YouTubePlayer.ready || YouTubePlayer.videoId !== ytId) {
        await YouTubePlayer.load(EditorState.audioUrl);
      }
      if (!editorRecording) return;
      EditorState.duration = YouTubePlayer.getDuration() || EditorState.duration;
      // Start from the beginning so the recording clock and audio have a stable zero.
      if (YouTubePlayer.ready && YouTubePlayer.player) {
        try { YouTubePlayer.player.seekTo(0, true); } catch (_) {}
      }
      YouTubePlayer.play();
      EditorState.recordingStartedAt = performance.now();
      return;
    } catch (err) {
      editorRecording = false;
      EditorState.recordingClockActive = false;
      btn.textContent = 'START RECORDING';
      const status = document.getElementById('editor-audio-status');
      if (status) status.textContent = err.message || 'Could not start YouTube playback.';
      return;
    }
  }

  const tempEra = { audioUrl: EditorState.audioObjectUrl, custom: true };
  CustomPlayer.start(tempEra);
  if (CustomPlayer.audioEl) {
    CustomPlayer.audioEl.addEventListener('ended', onEditorRecordingEnded, { once: true });
    CustomPlayer.audioEl.addEventListener('loadedmetadata', () => {
      EditorState.duration = CustomPlayer.audioEl.duration;
    }, { once: true });
  }
}

function onEditorRecordingEnded() {
  stopEditorRecordingIfActive();
}
window.onEditorRecordingEnded = onEditorRecordingEnded;

function stopEditorRecordingIfActive() {
  if (!editorRecording) return;
  editorRecording = false;
  EditorState.recordingClockActive = false;
  if (getYouTubeVideoId(EditorState.audioUrl || '')) {
    YouTubePlayer.onEnded = null;
    YouTubePlayer.pause();
  } else {
    CustomPlayer.stop();
  }
  const recordBtn = document.getElementById('editor-record-btn');
  recordBtn.classList.add('hidden');
  document.getElementById('editor-rerecord-btn').classList.remove('hidden');
  document.getElementById('editor-save-btn').classList.toggle('hidden', EditorState.notes.length === 0);
}

function getEditorRecordingTime() {
  if (!editorRecording && !EditorState.recordingClockActive) return 0;
  const elapsed = Math.max(0, (performance.now() - EditorState.recordingStartedAt) / 1000);
  if (getYouTubeVideoId(EditorState.audioUrl || '')) {
    const ytTime = YouTubePlayer.getCurrentTime();
    // Once YouTube is reporting real playback time, use it for note alignment.
    return YouTubePlayer.ready && (YouTubePlayer.playing || ytTime > 0.01) ? ytTime : elapsed;
  }
  const audioTime = CustomPlayer.getSongTime() - START_DELAY;
  return Math.max(0, CustomPlayer.started ? audioTime : elapsed - START_DELAY);
}

function recordEditorTap(lane) {
  if (!editorRecording) return;
  const t = getEditorRecordingTime();
  EditorState.notes.push({ lane, time: Math.max(0, t), hit: false, missed: false, y: -50, spawned: false });
  document.getElementById('editor-record-count').textContent = String(EditorState.notes.length);

  const tapEl = document.querySelector('.editor-tap-lane[data-lane="' + lane + '"]');
  if (tapEl) {
    tapEl.classList.add('active');
    setTimeout(() => tapEl.classList.remove('active'), 100);
  }
}

function updateEditorRecordingUI() {
  if (!editorRecording) return;
  const t = getEditorRecordingTime();
  const duration = Number.isFinite(EditorState.duration) ? EditorState.duration : 0;
  document.getElementById('editor-record-time').textContent = formatTime(t) + ' / ' + formatTime(duration);
}

document.getElementById('editor-record-btn').addEventListener('click', () => {
  if (editorRecording) {
    stopEditorRecordingIfActive();
  } else {
    startEditorRecording();
  }
});

document.getElementById('editor-rerecord-btn').addEventListener('click', () => {
  resetRecordingUI();
});

// Pointer tapping for the editor's on-screen lanes. This is the primary
// mobile recording path and works in Android WebView without duplicate taps.
document.querySelectorAll('.editor-tap-lane').forEach((el) => {
  const lane = parseInt(el.dataset.lane, 10);
  el.style.touchAction = 'none';
  el.addEventListener('pointerdown', (e) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    recordEditorTap(lane);
  }, { passive: false });
});

async function saveCustomLevelFromEditor() {
  if (EditorState.notes.length === 0 || (!EditorState.audioFile && !EditorState.audioUrl)) return;
  const name = document.getElementById('editor-name').value.trim() || 'Your Level';
  const sub = document.getElementById('editor-sub').value.trim() || 'A custom creation';
  const palette = buildPaletteFromEditor();
  const notes = EditorState.notes
    .slice()
    .sort((a, b) => a.time - b.time)
    .map(n => ({ lane: n.lane, time: START_DELAY + n.time, hit: false, missed: false, y: -50, spawned: false }));
  const duration = START_DELAY + Math.max(EditorState.duration, EditorState.notes.length ? EditorState.notes[EditorState.notes.length - 1].time : 0);

  const meta = { name, sub, audioUrl: EditorState.audioUrl || '', palette, buildings: readEditorBuildings(), chart: { notes, duration } };

  const saveBtn = document.getElementById('editor-save-btn');
  saveBtn.textContent = 'SAVING…';
  saveBtn.disabled = true;

  try {
    if (EditorState.audioFile) await saveCustomAudioBlob(EditorState.audioFile);
    saveCustomLevelMeta(meta);
    if (customLevel && customLevel.audioUrl) {
      try { URL.revokeObjectURL(customLevel.audioUrl); } catch (_error) {}
    }
    customLevel = buildCustomEra(meta, EditorState.audioFile || null);
    refreshActiveEras();
    updateTitleCustomButtons();
    closeEditor();
  } catch (_error) {
    alert("Couldn't save your level — your browser may be blocking local storage.");
  }

  saveBtn.textContent = 'SAVE LEVEL';
  saveBtn.disabled = false;
}

document.getElementById('editor-save-btn').addEventListener('click', saveCustomLevelFromEditor);

function updateTitleCustomButtons() {
  const playBtn = document.getElementById('play-custom-btn');
  const shareBtn = document.getElementById('share-custom-btn');
  const delBtn = document.getElementById('delete-custom-btn');
  const idBtn = document.getElementById('share-id-btn');
  if (customLevel) {
    playBtn.classList.remove('hidden'); shareBtn.classList.remove('hidden'); delBtn.classList.remove('hidden'); idBtn?.classList.remove('hidden');
  } else {
    playBtn.classList.add('hidden'); shareBtn.classList.add('hidden'); delBtn.classList.add('hidden'); idBtn?.classList.add('hidden');
  }
}

document.getElementById('play-custom-btn').addEventListener('click', () => {
  if (!customLevel) return;
  AudioEngine.init();
  AudioEngine.resume();
  document.getElementById('title-screen').classList.remove('active');
  resetGame();
  startLevel(ACTIVE_ERAS.length - 1);
});



// ---------- MOBILE LEVEL ID SHARING ----------
// A Level ID is a self-contained share code. It contains chart + visual data,
// so it works offline and across devices. Audio is intentionally not embedded:
// Music is not embedded in the ID. Direct HTTPS/YouTube URLs are carried as metadata so the recipient can stream the same source.
const LEVEL_ID_PREFIX = 'BW1-';
function encodeLevelId(payload) {
  const json = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(json);
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return LEVEL_ID_PREFIX + btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
function decodeLevelId(code) {
  code = String(code || '').trim().replace(/\s+/g, '');
  if (!code.startsWith(LEVEL_ID_PREFIX)) throw new Error('That is not a valid Beat Wayfarer Level ID.');
  let b64 = code.slice(LEVEL_ID_PREFIX.length).replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  const binary = atob(b64);
  const bytes = Uint8Array.from(binary, c => c.charCodeAt(0));
  return JSON.parse(new TextDecoder().decode(bytes));
}
function buildLevelIdPayload(meta) {
  return { v: 2, name: meta.name, sub: meta.sub, audioUrl: meta.audioUrl || '', palette: meta.palette, buildings: meta.buildings || {}, chart: meta.chart };
}
function currentLevelId() {
  const meta = loadCustomLevelMeta();
  if (!meta) throw new Error('Create or import a level first.');
  return encodeLevelId(buildLevelIdPayload(meta));
}
async function copyText(text) {
  if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); return true; }
  const ta = document.createElement('textarea'); ta.value = text; ta.style.position='fixed'; ta.style.opacity='0'; document.body.appendChild(ta); ta.select();
  let ok = false; try { ok = document.execCommand('copy'); } catch (_) {} ta.remove(); return ok;
}
async function shareLevelId() {
  try {
    const id = currentLevelId();
    const meta = loadCustomLevelMeta();
    const text = `Beat Wayfarer level: ${meta?.name || 'Custom Level'}
${id}`;
    if (navigator.share) { try { await navigator.share({ title: 'Beat Wayfarer Level', text }); return; } catch (e) { if (e?.name === 'AbortError') return; } }
    const copied = await copyText(id);
    if (copied) alert('Level ID copied! Send it to your friend.');
    else prompt('Copy this Beat Wayfarer Level ID:', id);
  } catch (e) { alert(e.message || 'Could not create the level ID.'); }
}
function showLevelIdPanel(show) {
  document.getElementById('level-id-panel')?.classList.toggle('hidden', !show);
  if (show) setTimeout(() => document.getElementById('level-id-input')?.focus(), 50);
}
async function importLevelId(code) {
  try {
    const payload=decodeLevelId(code);
    if(!payload.chart||!Array.isArray(payload.chart.notes))throw new Error('The Level ID is missing chart data.');
    const audioUrl=String(payload.audioUrl||'').trim();
    if(audioUrl&&!/^https:\/\//i.test(audioUrl))throw new Error('The shared music URL must use HTTPS.');
    const meta={name:String(payload.name||'Imported Level').slice(0,24),sub:String(payload.sub||'Imported creation').slice(0,40),audioUrl,palette:payload.palette||buildPaletteFromEditor(),buildings:payload.buildings||{},chart:{notes:payload.chart.notes.map(n=>({lane:Math.max(0,Math.min(LANES-1,Number(n.lane)||0)),time:Math.max(0,Number(n.time)||0),hit:false,missed:false,y:-50,spawned:false})),duration:Math.max(0,Number(payload.chart.duration)||0)}};
    saveCustomLevelMeta(meta);
    customLevel=audioUrl?buildCustomEra(meta,null):null;
    refreshActiveEras(); updateTitleCustomButtons(); showLevelIdPanel(false);
    alert(audioUrl?`Imported "${meta.name}" with its music URL.`:`Imported "${meta.name}". This ID has no music URL.`);
  }catch(e){alert(e.message||'Could not import that Level ID.');}
}

// ---------- LEVEL SHARING / IMPORT ----------
// v2 uses a small JSON header followed by the raw audio bytes. This avoids
// Base64's memory overhead and also makes browser file-sharing more reliable.
const LEVEL_SHARE_VERSION = 2;
const LEVEL_MAGIC = 'RRLEVEL2';

function downloadLevelFile(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = (name.replace(/[^\w -]+/g, '').trim().slice(0, 50) || 'Rhythm Rise Level') + '.rrlevel';
  a.style.display = 'none';
  document.body.appendChild(a);
  try { a.click(); } finally {
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
}

async function getShareLevelParts() {
  let audioBlob;
  let meta;

  if (customLevel && EditorState.audioFile) {
    audioBlob = EditorState.audioFile;
    meta = loadCustomLevelMeta();
  } else {
    audioBlob = await loadCustomAudioBlob();
    meta = loadCustomLevelMeta();
  }

  if (!audioBlob) throw new Error('This level uses a music URL. Use COPY LEVEL ID to share it on mobile.');
  if (!meta) throw new Error('No custom level data found.');

  return { audioBlob, meta };
}

async function makeShareableLevelFile() {
  const { audioBlob, meta } = await getShareLevelParts();
  const header = {
    format: 'RhythmRiseLevel',
    version: LEVEL_SHARE_VERSION,
    name: meta.name,
    sub: meta.sub,
    palette: meta.palette,
    chart: meta.chart,
    // Building customization is part of the share payload so imported levels
    // retain custom images, sizes, positions, and beat behavior.
    buildings: meta.buildings || { motion: 'static', amount: 0, offsetX: 0, offsetY: 0, bump: 0, width: 44, height: 80, imageScale: 100, imageMode: 'procedural', imageData: null },
    audioType: audioBlob.type || 'audio/mpeg',
  };

  // Header length is stored first, then the header JSON, then raw audio.
  const headerBytes = new TextEncoder().encode(JSON.stringify(header));
  const prefix = new TextEncoder().encode(LEVEL_MAGIC + '\n');
  const lengthBytes = new Uint8Array(4);
  new DataView(lengthBytes.buffer).setUint32(0, headerBytes.byteLength, true);

  return new Blob([prefix, lengthBytes, headerBytes, audioBlob], {
    type: 'application/octet-stream',
  });
}

async function parseLevelFile(file) {
  const probe = new Uint8Array(await file.slice(0, LEVEL_MAGIC.length + 5).arrayBuffer());
  const magic = new TextDecoder().decode(probe.slice(0, LEVEL_MAGIC.length));

  if (magic === LEVEL_MAGIC) {
    const headerLength = new DataView(probe.buffer, LEVEL_MAGIC.length + 1, 4).getUint32(0, true);
    const headerStart = LEVEL_MAGIC.length + 1 + 4;
    const headerBytes = new Uint8Array(await file.slice(headerStart, headerStart + headerLength).arrayBuffer());
    const payload = JSON.parse(new TextDecoder().decode(headerBytes));
    const audioBlob = file.slice(headerStart + headerLength, file.size, payload.audioType || 'audio/mpeg');
    return { payload, audioBlob };
  }

  // Backward compatibility with the original JSON/Base64 format.
  const payload = JSON.parse(await file.text());
  if (payload.format !== 'RhythmRiseLevel' || !payload.audioBase64) {
    throw new Error('This is not a compatible Rhythm Rise level file.');
  }
  const audioBytes = Uint8Array.from(atob(payload.audioBase64), c => c.charCodeAt(0));
  return {
    payload,
    audioBlob: new Blob([audioBytes], { type: payload.audioType || 'audio/mpeg' }),
  };
}

async function shareCustomLevel() {
  const btn = document.getElementById('share-custom-btn');
  btn.disabled = true;
  btn.textContent = 'PREPARING…';

  try {
    const blob = await makeShareableLevelFile();
    const meta = loadCustomLevelMeta();
    const safeName = (meta?.name || 'Rhythm Rise Level').replace(/[^\w -]+/g, '').trim() || 'Rhythm Rise Level';
    const file = new File([blob], safeName.slice(0, 50) + '.rrlevel', { type: 'application/octet-stream' });

    // navigator.share can be present but still reject file sharing due to
    // browser permissions, HTTPS/origin rules, or desktop limitations.
    // Those failures are not export failures, so gracefully download instead.
    let shared = false;
    if (navigator.share && navigator.canShare) {
      try {
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: meta?.name || 'Rhythm Rise Level',
            text: 'Play my Rhythm Rise level!',
            files: [file],
          });
          shared = true;
        }
      } catch (error) {
        if (error?.name === 'AbortError') return;
        console.warn('Native sharing unavailable, using download fallback:', error);
      }
    }

    if (!shared) {
      downloadLevelFile(blob, safeName);
      alert('Your level was exported as a .rrlevel file. Send that file to your friends, and they can use IMPORT LEVEL.');
    }
  } catch (error) {
    console.error('Level export failed:', error);
    alert(`Could not export the level: ${error?.message || 'Unknown error.'}`);
  } finally {
    btn.disabled = false;
    btn.textContent = 'SHARE LEVEL';
  }
}

async function importLevelFile(file) {
  if (!file) return;
  try {
    if (file.size > 500 * 1024 * 1024) {
      throw new Error('This level file is over 500 MB.');
    }

    const { payload, audioBlob } = await parseLevelFile(file);
    if (payload.format !== 'RhythmRiseLevel' || ![1, 2].includes(Number(payload.version))) {
      throw new Error('This is not a compatible Rhythm Rise level file.');
    }
    if (!payload.chart || !Array.isArray(payload.chart.notes)) {
      throw new Error('The level file is missing required chart data.');
    }
    if (!audioBlob || !audioBlob.size) {
      throw new Error('The level file is missing its music.');
    }

    const meta = {
      name: String(payload.name || 'Imported Level').slice(0, 24),
      sub: String(payload.sub || 'Imported creation').slice(0, 40),
      palette: payload.palette || buildPaletteFromEditor(),
      buildings: payload.buildings || { motion: 'static', amount: 0, offsetX: 0, offsetY: 0, bump: 0, width: 44, height: 80, imageScale: 100, imageMode: 'procedural', imageData: null },
      chart: {
        notes: payload.chart.notes.map(n => ({
          lane: Math.max(0, Math.min(LANES - 1, Number(n.lane) || 0)),
          time: Math.max(0, Number(n.time) || 0),
          hit: false,
          missed: false,
          y: -50,
          spawned: false,
        })),
        duration: Math.max(0, Number(payload.chart.duration) || 0),
      },
    };

    await saveCustomAudioBlob(audioBlob);
    saveCustomLevelMeta(meta);

    if (customLevel?.audioUrl) {
      try { URL.revokeObjectURL(customLevel.audioUrl); } catch (_error) {}
    }
    customLevel = buildCustomEra(meta, audioBlob);
    refreshActiveEras();
    updateTitleCustomButtons();

    alert(`Imported "${meta.name}" successfully!`);
  } catch (error) {
    console.error(error);
    alert(error.message || 'Could not import that level file.');
  }
}

document.getElementById('share-custom-btn').addEventListener('click', shareCustomLevel);
document.getElementById('share-id-btn')?.addEventListener('click', shareLevelId);
document.getElementById('import-id-btn')?.addEventListener('click', () => showLevelIdPanel(true));
document.getElementById('level-id-cancel')?.addEventListener('click', () => showLevelIdPanel(false));
document.getElementById('level-id-import')?.addEventListener('click', () => importLevelId(document.getElementById('level-id-input')?.value || ''));

document.getElementById('import-level-btn').addEventListener('click', () => {
  document.getElementById('import-level-file').click();
});

document.getElementById('import-level-file').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  await importLevelFile(file);
});

document.getElementById('delete-custom-btn').addEventListener('click', () => {
  if (!confirm('Delete your custom level? This cannot be undone.')) return;
  deleteCustomLevel();
  updateTitleCustomButtons();
});

// ---------- CHEAT CODE LEVEL SELECT ----------
const CHEAT_CODE = '1513';
function openCheatPanel() {
  document.getElementById('cheat-panel')?.classList.remove('hidden');
  document.getElementById('cheat-code-input')?.focus();
  const picker=document.getElementById('cheat-level-picker'); if(picker) picker.classList.add('hidden');
  const status=document.getElementById('cheat-status'); if(status) status.textContent='';
}
function closeCheatPanel() { document.getElementById('cheat-panel')?.classList.add('hidden'); }
function populateCheatLevels() {
  const select=document.getElementById('cheat-level-select'); if(!select) return;
  select.innerHTML='';
  ACTIVE_ERAS.forEach((era,i)=>{
    const option=document.createElement('option'); option.value=String(i); option.textContent=`Level ${i+1} — ${era.name}`; select.appendChild(option);
  });
}
function unlockCheatCode() {
  const input=document.getElementById('cheat-code-input');
  const status=document.getElementById('cheat-status');
  if((input?.value||'').trim() !== CHEAT_CODE) { if(status) status.textContent='INVALID CODE'; return; }
  populateCheatLevels();
  document.getElementById('cheat-level-picker')?.classList.remove('hidden');
  if(status) status.textContent='ALL LEVELS UNLOCKED';
}
function playCheatLevel() {
  const select=document.getElementById('cheat-level-select');
  const idx=Number(select?.value);
  if(!Number.isInteger(idx) || idx<0 || idx>=ACTIVE_ERAS.length) return;
  AudioEngine.init(); AudioEngine.resume();
  closeCheatPanel();
  document.getElementById('title-screen')?.classList.remove('active');
  document.getElementById('game-over')?.classList.remove('active');
  document.getElementById('level-complete')?.classList.remove('active');
  document.getElementById('victory')?.classList.remove('active');
  resetGame();
  startLevel(idx);
}
document.getElementById('cheat-code-btn')?.addEventListener('click', openCheatPanel);
document.getElementById('cheat-cancel-btn')?.addEventListener('click', closeCheatPanel);
document.getElementById('cheat-unlock-btn')?.addEventListener('click', unlockCheatCode);
document.getElementById('cheat-play-btn')?.addEventListener('click', playCheatLevel);
document.getElementById('cheat-code-input')?.addEventListener('keydown', e => { if(e.key==='Enter') unlockCheatCode(); });

// ---------- UI BUTTONS ----------
document.getElementById('start-btn').addEventListener('click', () => {
  AudioEngine.init();
  AudioEngine.resume();
  document.getElementById('title-screen').classList.remove('active');
  resetGame();
  startLevel(0);
});

document.getElementById('next-btn').addEventListener('click', () => {
  document.getElementById('level-complete').classList.remove('active');
  const nextIndex = GameState.levelIndex + 1;
  if (nextIndex < ACTIVE_ERAS.length) {
    startLevel(nextIndex);
  } else {
    document.getElementById('victory').classList.add('active');
    GameState.phase = 'victory';
  }
});

document.getElementById('retry-btn').addEventListener('click', () => {
  // A loss now restarts the level where the player fell instead of sending
  // them all the way back to Level 1.
  document.getElementById('game-over').classList.remove('active');
  const retryLevel = 0; // Losing any level restarts the game from Level 1.
  GameState.score = 0;
  GameState.combo = 0;
  GameState.maxCombo = 0;
  GameState.hp = HP_MAX;
  GameState.perfects = 0;
  GameState.goods = 0;
  GameState.misses = 0;
  GameState.strayMisses = 0;
  GameState.missPenalty = 0;
  GameState.particles = [];
  GameState.notes = [];
  GameState.finaleCutscene = false;
  GameState.finaleCutsceneShown = false;
  startLevel(retryLevel);
});

document.getElementById('victory-retry-btn').addEventListener('click', () => {
  document.getElementById('victory').classList.remove('active');
  resetGame();
  startLevel(0);
});

// Debug toggle (press Backquote/Tilde)
document.addEventListener('keydown', (e) => {
  if (e.code === 'Backquote') {
    const dbg = document.getElementById('debug');
    dbg.classList.toggle('hidden');
  }
});

// ---------- LOCAL PROFILE / FIRST-LAUNCH USERNAME ----------
const USERNAME_STORAGE_KEY = 'beatWayfarerUsername';

function getSavedUsername() {
  try { return (localStorage.getItem(USERNAME_STORAGE_KEY) || '').trim(); } catch (_) { return ''; }
}

function applyUsername(username) {
  const clean = String(username || '').trim().replace(/\s+/g, ' ').slice(0, 16);
  const display = document.getElementById('player-username');
  const profile = document.getElementById('player-profile');
  if (display) display.textContent = clean || 'PLAYER';
  if (profile) profile.classList.toggle('hidden', !clean);
  return clean;
}

function showUsernamePrompt() {
  const modal = document.getElementById('username-modal');
  const input = document.getElementById('username-input');
  const error = document.getElementById('username-error');
  if (!modal) return;
  modal.classList.add('active');
  if (error) error.textContent = '';
  setTimeout(() => input?.focus(), 80);
}

function finishUsernamePrompt() {
  const input = document.getElementById('username-input');
  const error = document.getElementById('username-error');
  const value = applyUsername(input?.value);
  if (value.length < 2) {
    if (error) error.textContent = 'Please enter at least 2 characters.';
    input?.focus();
    return;
  }
  try { localStorage.setItem(USERNAME_STORAGE_KEY, value); } catch (_) {}
  document.getElementById('username-modal')?.classList.remove('active');
}

function initUsername() {
  const saved = getSavedUsername();
  applyUsername(saved);
  const save = document.getElementById('username-save-btn');
  const input = document.getElementById('username-input');
  save?.addEventListener('click', finishUsernamePrompt);
  input?.addEventListener('keydown', (e) => { if (e.key === 'Enter') finishUsernamePrompt(); });
  if (!saved) {
    const intro = document.getElementById('studio-intro');
    const wait = intro ? 3700 : 100;
    setTimeout(showUsernamePrompt, wait);
  }
}

// ---------- INIT ----------
Input.init();
initUsername();

// Load a previously-saved custom level (if any) and reflect it on the title screen
loadCustomLevelFromStorage().then(() => updateTitleCustomButtons());

// Debug hook for testing
window.__getSongTime = () => Song.getSongTime();
window.__getGameState = () => ({
  phase: GameState.phase,
  score: GameState.score,
  combo: GameState.combo,
  hp: GameState.hp,
  notesActive: GameState.notes.filter(n => !n.hit && !n.missed).length,
  nextNote: GameState.notes.find(n => !n.hit && !n.missed),
});
window.__pressLane = (lane) => { if (GameState.phase === 'playing') checkInput(lane); };

// Start the game loop with title screen
requestAnimationFrame((t) => {
  lastTime = t;
  gameLoop(t);
});

// Flightly33 studio intro: logo fades in, holds, then fades out before play.
const studioIntro = document.getElementById('studio-intro');
if (studioIntro) {
  const finishIntro = () => {
    if (studioIntro.dataset.finished) return;
    studioIntro.dataset.finished = '1';
    studioIntro.classList.add('studio-intro-hidden');
    setTimeout(() => studioIntro.remove(), 900);
  };
  studioIntro.addEventListener('animationend', (event) => {
    if (event.animationName === 'studioIntroFade') finishIntro();
  }, { once: true });
  setTimeout(finishIntro, 3600);
}

console.log('Beat Wayfarer initialized');

})();
